package com.ghamis.system;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.widget.Toast;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean loaded = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap icon) { super.onPageStarted(v,url,icon); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url != null && url.startsWith("http://127.0.0.1:8765")) return false;
                return true;
            }
        });
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        new Thread(() -> {
            try {
                Python.getInstance().getModule("server").callAttr("start_server", getFilesDir().getAbsolutePath());
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this, "تعذر تشغيل النظام: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
        waitForServer();
    }

    private void waitForServer() {
        new Thread(() -> {
            for (int i=0; i<60; i++) {
                try {
                    HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8765/health").openConnection();
                    c.setConnectTimeout(500); c.setReadTimeout(500);
                    int code=c.getResponseCode(); c.disconnect();
                    if (code >= 200 && code < 500) {
                        runOnUiThread(() -> { if (!loaded) { loaded=true; web.loadUrl("http://127.0.0.1:8765/"); } });
                        return;
                    }
                } catch(Exception ignored) {}
                try { Thread.sleep(500); } catch(InterruptedException ignored) {}
            }
            runOnUiThread(() -> Toast.makeText(this, "تأخر تشغيل النظام. أغلق التطبيق وافتحه مرة أخرى.", Toast.LENGTH_LONG).show());
        }).start();
    }

    private class PrintBridge {
        @android.webkit.JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    String jobName="نظام الغميس - تقرير";
                    pm.print(jobName, web.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch(Exception e) { Toast.makeText(MainActivity.this,"تعذر فتح حفظ PDF",Toast.LENGTH_LONG).show(); }
            });
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { if(web!=null) web.destroy(); super.onDestroy(); }
}
