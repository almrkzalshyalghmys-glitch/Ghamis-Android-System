from fastapi import FastAPI, Form, Request
from fastapi.responses import RedirectResponse, HTMLResponse, Response, FileResponse
import sqlite3
from datetime import date, datetime
from html import escape
from urllib.parse import quote
from pathlib import Path
import os
import shutil
import hashlib
import hmac
import secrets
import threading

# تحميل WeasyPrint مع مكتبات MSYS2 تلقائيًا على Windows
WEASYPRINT_DLL_DIR = r"C:\msys64\ucrt64\bin"
WEASYPRINT_DLL_HANDLE = None

if os.path.isdir(WEASYPRINT_DLL_DIR):
    os.environ["WEASYPRINT_DLL_DIRECTORIES"] = WEASYPRINT_DLL_DIR
    current_path = os.environ.get("PATH", "")
    path_parts = current_path.split(";") if current_path else []
    if WEASYPRINT_DLL_DIR.lower() not in [p.lower().rstrip("\\") for p in path_parts]:
        os.environ["PATH"] = WEASYPRINT_DLL_DIR + ";" + current_path
    try:
        WEASYPRINT_DLL_HANDLE = os.add_dll_directory(WEASYPRINT_DLL_DIR)
    except Exception:
        WEASYPRINT_DLL_HANDLE = None

try:
    from weasyprint import HTML as WeasyHTML
except Exception:
    WeasyHTML = None


# =========================================================
# إعداد البرنامج
# =========================================================

app = FastAPI(title="نظام مشروع الغميس")
BASE_DIR = Path(os.environ.get("GHMAIS_DATA_DIR", str(Path(__file__).resolve().parent))).resolve()
DB_NAME = str(BASE_DIR / "WaterElectricity" / "database.db")
BACKUP_DIR = BASE_DIR / "Backup"
BACKUP_DIR.mkdir(exist_ok=True)

PUBLIC_BASE_URL = os.getenv("GHMAIS_PUBLIC_BASE_URL", "").rstrip("/")
PORT = int(os.getenv("PORT", "8000"))

DEFAULT_PASSWORD = "1234"
APP_SECRET = os.getenv("GHMAIS_APP_SECRET", "ghmais-public-link-secret-change-me").encode("utf-8")


# =========================================================
# قاعدة البيانات
# =========================================================

AUTO_BACKUP_ENABLED = False
AUTO_BACKUP_LOCK = threading.Lock()

def _file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _create_auto_backup_if_changed():
    source = Path(DB_NAME)
    if not source.exists():
        return

    with AUTO_BACKUP_LOCK:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        existing = sorted(
            [p for p in BACKUP_DIR.glob("database_backup_*.db") if p.is_file()],
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        temp = BACKUP_DIR / f".auto_backup_{secrets.token_hex(8)}.db"

        src = sqlite3.connect(str(source), timeout=30)
        dst = sqlite3.connect(str(temp), timeout=30)
        try:
            src.execute("PRAGMA wal_checkpoint(PASSIVE)")
            src.backup(dst)
            dst.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            check = dst.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                raise RuntimeError("فشل فحص سلامة النسخة الاحتياطية التلقائية")
            dst.commit()
        finally:
            dst.close()
            src.close()

        if existing and _file_sha256(temp) == _file_sha256(existing[0]):
            temp.unlink(missing_ok=True)
            return

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")
        final = BACKUP_DIR / f"database_backup_{timestamp}.db"
        temp.replace(final)

        backups = sorted(
            [p for p in BACKUP_DIR.glob("database_backup_*.db") if p.is_file()],
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old in backups[2:]:
            try:
                old.unlink()
            except Exception:
                pass

class GhamisConnection(sqlite3.Connection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._auto_backup_dirty = False
        self.set_trace_callback(self._trace_for_auto_backup)

    def _trace_for_auto_backup(self, statement):
        sql = statement.lstrip().upper()
        if sql.startswith(("INSERT ", "UPDATE ", "DELETE ", "REPLACE ", "ALTER ", "CREATE ", "DROP ")):
            self._auto_backup_dirty = True

    def commit(self):
        super().commit()
        dirty = self._auto_backup_dirty
        self._auto_backup_dirty = False
        if dirty and AUTO_BACKUP_ENABLED:
            try:
                _create_auto_backup_if_changed()
            except Exception as exc:
                print(f"WARNING: automatic backup failed: {exc}")

    def rollback(self):
        try:
            super().rollback()
        finally:
            self._auto_backup_dirty = False

def get_connection():
    conn = sqlite3.connect(DB_NAME, timeout=30, factory=GhamisConnection)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def column_exists(conn, table_name, column_name):
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return any(r[1] == column_name for r in rows)


def add_column_if_missing(conn, table_name, column_name, definition):
    if not column_exists(conn, table_name, column_name):
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}")


def create_tables():
    c = get_connection()
    x = c.cursor()

    x.execute("""
        CREATE TABLE IF NOT EXISTS subscribers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            previous_arrears REAL DEFAULT 0,
            notes TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS meters(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscriber_id INTEGER NOT NULL,
            meter_type TEXT NOT NULL,
            actual_meter_number TEXT,
            status TEXT DEFAULT 'يعمل',
            notes TEXT,
            FOREIGN KEY(subscriber_id) REFERENCES subscribers(id)
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS prices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meter_type TEXT NOT NULL,
            unit_price REAL NOT NULL,
            start_date TEXT NOT NULL,
            active INTEGER DEFAULT 1,
            notes TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS readings(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meter_id INTEGER NOT NULL,
            reading_date TEXT NOT NULL,
            previous_reading REAL DEFAULT 0,
            current_reading REAL NOT NULL,
            consumption REAL DEFAULT 0,
            unit_price REAL DEFAULT 0,
            consumption_value REAL DEFAULT 0,
            notes TEXT,
            FOREIGN KEY(meter_id) REFERENCES meters(id)
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscriber_id INTEGER NOT NULL,
            invoice_date TEXT NOT NULL,
            consumption_total REAL DEFAULT 0,
            previous_arrears REAL DEFAULT 0,
            total_due REAL DEFAULT 0,
            amount_words TEXT,
            notes TEXT,
            closed INTEGER DEFAULT 0,
            FOREIGN KEY(subscriber_id) REFERENCES subscribers(id)
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS invoice_details(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            meter_id INTEGER NOT NULL,
            meter_type TEXT NOT NULL,
            actual_meter_number TEXT,
            previous_reading REAL DEFAULT 0,
            current_reading REAL DEFAULT 0,
            consumption REAL DEFAULT 0,
            unit_price REAL DEFAULT 0,
            consumption_value REAL DEFAULT 0,
            FOREIGN KEY(invoice_id) REFERENCES invoices(id),
            FOREIGN KEY(meter_id) REFERENCES meters(id)
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            subscriber_id INTEGER NOT NULL,
            payment_date TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0,
            notes TEXT,
            FOREIGN KEY(invoice_id) REFERENCES invoices(id),
            FOREIGN KEY(subscriber_id) REFERENCES subscribers(id)
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_date TEXT NOT NULL,
            item TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0,
            notes TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS employees(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            job TEXT,
            salary REAL DEFAULT 0,
            notes TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS salaries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            salary_date TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0,
            notes TEXT,
            base_salary REAL NOT NULL DEFAULT 0,
            additions REAL NOT NULL DEFAULT 0,
            deductions REAL NOT NULL DEFAULT 0,
            net_amount REAL NOT NULL DEFAULT 0,
            paid INTEGER NOT NULL DEFAULT 0,
            payment_date TEXT,
            FOREIGN KEY(employee_id) REFERENCES employees(id)
        )
    """)

    salary_cols = {row[1] for row in x.execute("PRAGMA table_info(salaries)").fetchall()}
    for col, definition in [
        ("base_salary", "REAL NOT NULL DEFAULT 0"),
        ("additions", "REAL NOT NULL DEFAULT 0"),
        ("deductions", "REAL NOT NULL DEFAULT 0"),
        ("net_amount", "REAL NOT NULL DEFAULT 0"),
        ("paid", "INTEGER NOT NULL DEFAULT 0"),
        ("payment_date", "TEXT"),
    ]:
        if col not in salary_cols:
            x.execute(f"ALTER TABLE salaries ADD COLUMN {col} {definition}")
    x.execute("UPDATE salaries SET base_salary=CASE WHEN base_salary=0 THEN amount ELSE base_salary END, net_amount=CASE WHEN net_amount=0 THEN amount ELSE net_amount END WHERE amount IS NOT NULL")

    x.execute("""
        CREATE TABLE IF NOT EXISTS donations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            donation_date TEXT NOT NULL,
            donor TEXT,
            amount REAL NOT NULL DEFAULT 0,
            purpose TEXT,
            notes TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS program_settings(
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    x.execute("""
        CREATE TABLE IF NOT EXISTS whatsapp_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscriber_id INTEGER,
            invoice_id INTEGER,
            sent_at TEXT NOT NULL,
            kind TEXT NOT NULL,
            phone TEXT,
            message TEXT,
            status TEXT DEFAULT 'مجهز للواتساب',
            FOREIGN KEY(subscriber_id) REFERENCES subscribers(id),
            FOREIGN KEY(invoice_id) REFERENCES invoices(id)
        )
    """)

    # توافق مع قاعدة البيانات السابقة: لا نحذف أي بيانات.
    add_column_if_missing(c, "readings", "invoice_id", "INTEGER")

    # أول تشغيل: رمز دخول افتراضي يمكن تغييره من داخل البرنامج.
    existing = x.execute(
        "SELECT value FROM program_settings WHERE key='password_hash'"
    ).fetchone()
    if not existing:
        x.execute(
            "INSERT INTO program_settings(key,value) VALUES('password_hash',?)",
            (hash_password(DEFAULT_PASSWORD),)
        )

    c.commit()
    c.close()


def hash_password(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120000)
    return salt.hex() + ":" + digest.hex()


def verify_password(password, stored):
    try:
        salt_hex, digest_hex = stored.split(":", 1)
        salt = bytes.fromhex(salt_hex)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120000)
        return hmac.compare_digest(digest.hex(), digest_hex)
    except Exception:
        return False


create_tables()
AUTO_BACKUP_ENABLED = True


# =========================================================
# أدوات عامة
# =========================================================

def money(value):
    try:
        value = float(value)
    except Exception:
        value = 0.0
    if value.is_integer():
        return f"{int(value):,} ر.ي"
    return f"{value:,.2f} ر.ي"


def esc(value):
    return escape(str(value if value is not None else ""))


AUTH_COOKIE = "ghmais_auth"
AUTH_TOKEN = hmac.new(APP_SECRET, b"ghmais-auth", hashlib.sha256).hexdigest()

def set_flash(request, message, level="success"):
    request.state.flash = {"message": message, "level": level}


def get_flash(request):
    return getattr(request.state, "flash", None)


def account_balance(cur, subscriber_id):
    row = cur.execute("""
        SELECT
            COALESCE((SELECT previous_arrears FROM subscribers WHERE id=?),0)
            + COALESCE((SELECT SUM(consumption_value) FROM readings r
                        JOIN meters m ON r.meter_id=m.id
                        WHERE m.subscriber_id=?),0)
            - COALESCE((SELECT SUM(amount) FROM payments WHERE subscriber_id=?),0)
    """, (subscriber_id, subscriber_id, subscriber_id)).fetchone()
    return max(0.0, float(row[0] or 0))


def previous_arrears_before_current_invoice(cur, subscriber_id, exclude_invoice_id=None):
    """الرصيد المتراكم قبل دورة الفاتورة الحالية، دون مضاعفة المتأخرات."""
    initial = cur.execute(
        "SELECT previous_arrears FROM subscribers WHERE id=?",
        (subscriber_id,)
    ).fetchone()
    balance = float(initial[0] or 0) if initial else 0.0

    params = [subscriber_id]
    sql = """
        SELECT COALESCE(SUM(consumption_total),0)
        FROM invoices
        WHERE subscriber_id=?
    """
    if exclude_invoice_id is not None:
        sql += " AND id<>?"
        params.append(exclude_invoice_id)
    row = cur.execute(sql, params).fetchone()
    balance += float(row[0] or 0)

    params = [subscriber_id]
    sql = "SELECT COALESCE(SUM(amount),0) FROM payments WHERE subscriber_id=?"
    if exclude_invoice_id is not None:
        sql += " AND invoice_id<>?"
        params.append(exclude_invoice_id)
    row = cur.execute(sql, params).fetchone()
    balance -= float(row[0] or 0)

    return max(0.0, balance)


def invoice_paid(cur, invoice_id, exclude_payment_id=None):
    if exclude_payment_id is None:
        row = cur.execute(
            "SELECT COALESCE(SUM(amount),0) FROM payments WHERE invoice_id=?",
            (invoice_id,)
        ).fetchone()
    else:
        row = cur.execute(
            "SELECT COALESCE(SUM(amount),0) FROM payments WHERE invoice_id=? AND id<>?",
            (invoice_id, exclude_payment_id)
        ).fetchone()
    return float(row[0] or 0)


def invoice_balance(cur, invoice_id, exclude_payment_id=None):
    row = cur.execute(
        "SELECT total_due FROM invoices WHERE id=?",
        (invoice_id,)
    ).fetchone()
    if not row:
        return 0.0
    return max(0.0, float(row[0] or 0) - invoice_paid(cur, invoice_id, exclude_payment_id))


def get_open_invoice_id(cur, subscriber_id):
    row = cur.execute("""
        SELECT id
        FROM invoices
        WHERE subscriber_id=? AND closed=0
        ORDER BY id DESC
        LIMIT 1
    """, (subscriber_id,)).fetchone()
    return int(row[0]) if row else None


def latest_reading(cur, meter_id):
    return cur.execute("""
        SELECT id,reading_date,previous_reading,current_reading,consumption,unit_price,consumption_value,invoice_id
        FROM readings
        WHERE meter_id=?
        ORDER BY reading_date DESC,id DESC
        LIMIT 1
    """, (meter_id,)).fetchone()


def price_for_date(cur, meter_type, reading_date):
    row = cur.execute("""
        SELECT unit_price
        FROM prices
        WHERE meter_type=? AND active=1 AND start_date<=?
        ORDER BY start_date DESC,id DESC
        LIMIT 1
    """, (meter_type, reading_date)).fetchone()
    return float(row[0]) if row else None


def new_invoice_for_reading(cur, subscriber_id, reading_date):
    arrears = previous_arrears_before_current_invoice(cur, subscriber_id)
    cur.execute("""
        INSERT INTO invoices(
            subscriber_id,invoice_date,consumption_total,
            previous_arrears,total_due,amount_words,closed
        ) VALUES(?,?,?,?,?,?,0)
    """, (
        subscriber_id,
        reading_date,
        0,
        arrears,
        arrears,
        number_to_arabic_words(arrears),
    ))
    return cur.lastrowid


def build_invoice(cur, subscriber_id, invoice_id):
    """إعادة بناء الفاتورة المفتوحة من القراءات المرتبطة بها فقط."""
    inv = cur.execute(
        "SELECT * FROM invoices WHERE id=? AND subscriber_id=?",
        (invoice_id, subscriber_id)
    ).fetchone()
    if not inv:
        return None
    if int(inv["closed"] or 0):
        return invoice_id

    rows = cur.execute("""
        SELECT
            r.id AS reading_id,
            r.meter_id,
            r.reading_date,
            r.previous_reading,
            r.current_reading,
            r.consumption,
            r.unit_price,
            r.consumption_value,
            m.meter_type,
            m.actual_meter_number
        FROM readings r
        JOIN meters m ON r.meter_id=m.id
        WHERE r.invoice_id=?
        ORDER BY r.id
    """, (invoice_id,)).fetchall()

    cur.execute("DELETE FROM invoice_details WHERE invoice_id=?", (invoice_id,))

    total = 0.0
    used_meters = set()

    for r in rows:
        if r["meter_id"] in used_meters:
            continue
        used_meters.add(r["meter_id"])
        total += float(r["consumption_value"] or 0)
        cur.execute("""
            INSERT INTO invoice_details(
                invoice_id,meter_id,meter_type,actual_meter_number,
                previous_reading,current_reading,consumption,
                unit_price,consumption_value
            ) VALUES(?,?,?,?,?,?,?,?,?)
        """, (
            invoice_id,
            r["meter_id"],
            r["meter_type"],
            r["actual_meter_number"] or "",
            float(r["previous_reading"] or 0),
            float(r["current_reading"] or 0),
            float(r["consumption"] or 0),
            float(r["unit_price"] or 0),
            float(r["consumption_value"] or 0),
        ))

    arrears = float(inv["previous_arrears"] or 0)
    due = arrears + total

    cur.execute("""
        UPDATE invoices
        SET invoice_date=COALESCE((SELECT MIN(reading_date) FROM readings WHERE invoice_id=?),invoice_date),
            consumption_total=?,
            previous_arrears=?,
            total_due=?,
            amount_words=?
        WHERE id=? AND closed=0
    """, (
        invoice_id,
        total,
        arrears,
        due,
        number_to_arabic_words(due),
        invoice_id,
    ))

    return invoice_id


def refresh_open_invoice_for_subscriber(cur, subscriber_id):
    iid = get_open_invoice_id(cur, subscriber_id)
    if iid is None:
        return None
    arrears = previous_arrears_before_current_invoice(cur, subscriber_id, iid)
    cur.execute(
        "UPDATE invoices SET previous_arrears=? WHERE id=? AND closed=0",
        (arrears, iid)
    )
    build_invoice(cur, subscriber_id, iid)
    return iid


def safe_delete_invoice(cur, invoice_id):
    cur.execute("DELETE FROM payments WHERE invoice_id=?", (invoice_id,))
    cur.execute("UPDATE readings SET invoice_id=NULL WHERE invoice_id=?", (invoice_id,))
    cur.execute("DELETE FROM invoice_details WHERE invoice_id=?", (invoice_id,))
    cur.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))


def normalize_phone(phone):
    raw = "".join(ch for ch in str(phone or "") if ch.isdigit())
    if raw.startswith("00"):
        raw = raw[2:]
    if raw.startswith("0"):
        raw = "967" + raw[1:]
    elif len(raw) == 9:
        raw = "967" + raw
    return raw


def whatsapp_url(phone, message):
    p = normalize_phone(phone)
    if not p:
        return ""
    return f"https://wa.me/{p}?text={quote(message)}"


def public_token(invoice_id):
    return hmac.new(APP_SECRET, str(invoice_id).encode("utf-8"), hashlib.sha256).hexdigest()[:32]


def public_base(request):
    return PUBLIC_BASE_URL or str(request.base_url).rstrip("/")


def public_invoice_url(request, invoice_id, pdf=False):
    base = public_base(request)
    token = public_token(invoice_id)
    if pdf:
        return f"{base}/shared/invoice/{invoice_id}/pdf?token={token}"
    return f"{base}/shared/invoice/{invoice_id}?token={token}"


# =========================================================
# تحويل الأرقام إلى كتابة
# =========================================================

ONES = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"]
TEENS = {
    10:"عشرة", 11:"أحد عشر", 12:"اثنا عشر", 13:"ثلاثة عشر", 14:"أربعة عشر",
    15:"خمسة عشر", 16:"ستة عشر", 17:"سبعة عشر", 18:"ثمانية عشر", 19:"تسعة عشر"
}
TENS = {20:"عشرون",30:"ثلاثون",40:"أربعون",50:"خمسون",60:"ستون",70:"سبعون",80:"ثمانون",90:"تسعون"}
HUNDREDS = {
    100:"مائة",200:"مائتان",300:"ثلاثمائة",400:"أربعمائة",500:"خمسمائة",
    600:"ستمائة",700:"سبعمائة",800:"ثمانمائة",900:"تسعمائة"
}


def convert_under_100(n):
    if n < 10:
        return ONES[n]
    if n < 20:
        return TEENS[n]
    t = (n // 10) * 10
    o = n % 10
    return TENS[t] if o == 0 else ONES[o] + " و" + TENS[t]


def convert_under_1000(n):
    if n < 100:
        return convert_under_100(n)
    h = (n // 100) * 100
    r = n % 100
    return HUNDREDS[h] if r == 0 else HUNDREDS[h] + " و" + convert_under_100(r)


def number_to_arabic_words(number):
    try:
        number = int(round(float(number)))
    except Exception:
        number = 0
    if number == 0:
        return "صفر ريال يمني لا غير"
    if number < 0:
        return "سالب " + number_to_arabic_words(abs(number))

    parts = []
    millions = number // 1_000_000
    thousands = (number % 1_000_000) // 1000
    remainder = number % 1000

    if millions:
        if millions == 1:
            parts.append("مليون")
        elif millions == 2:
            parts.append("مليونان")
        elif 3 <= millions <= 10:
            parts.append(convert_under_1000(millions) + " ملايين")
        else:
            parts.append(convert_under_1000(millions) + " مليون")

    if thousands:
        if thousands == 1:
            parts.append("ألف")
        elif thousands == 2:
            parts.append("ألفان")
        elif 3 <= thousands <= 10:
            parts.append(convert_under_1000(thousands) + " آلاف")
        else:
            parts.append(convert_under_1000(thousands) + " ألف")

    if remainder:
        parts.append(convert_under_1000(remainder))

    return " و".join(parts) + " ريال يمني لا غير"


# =========================================================
# المصادقة
# =========================================================

PUBLIC_PATHS = {"/login", "/health"}


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    path = request.url.path
    allowed = (
        path in PUBLIC_PATHS
        or path.startswith("/shared/")
        or path.startswith("/assets/")
    )

    if not allowed and request.cookies.get(AUTH_COOKIE) != AUTH_TOKEN:
        return RedirectResponse("/login", status_code=303)

    flash_cookie = request.cookies.get("ghmais_flash")
    if flash_cookie:
        try:
            raw = bytes.fromhex(flash_cookie).decode("utf-8")
            message, level = raw.split("|", 1)
            request.state.flash = {"message": message, "level": level}
        except Exception:
            pass

    response = await call_next(request)

    # منع المتصفح من الاحتفاظ بصفحات البرنامج في الذاكرة/الكاش،
    # حتى لا يؤدي سهم الرجوع أو التالي إلى إظهار البرنامج بعد الخروج.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

    # امسح رسالة التنبيه بعد عرضها مرة واحدة.
    if flash_cookie:
        response.delete_cookie("ghmais_flash", path="/")

    # إذا قامت الصفحة الحالية بتعيين رسالة قبل إعادة التوجيه، خزّنها في كوكي.
    state_flash = getattr(request.state, "flash", None)
    if state_flash and not flash_cookie and response.status_code in (301,302,303,307,308):
        raw = f"{state_flash['message']}|{state_flash['level']}".encode("utf-8").hex()
        response.set_cookie("ghmais_flash", raw, max_age=20, httponly=True, samesite="lax", path="/")

    return response


# =========================================================
# واجهة النظام
# =========================================================

GLOBAL_CSS = """
<style>
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:Arial,Tahoma,sans-serif;direction:rtl;background:#f4f7fb;color:#1f2937}
a{text-decoration:none}
.topbar{background:linear-gradient(135deg,#0d47a1,#1565c0,#1976d2);color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;gap:15px;position:sticky;top:0;z-index:20}
.brand{font-size:21px;font-weight:800}.brand small{display:block;font-size:11px;font-weight:normal;opacity:.9;margin-top:3px}
.nav{background:#fff;border-bottom:1px solid #dbe2ea;padding:9px 14px;display:flex;flex-wrap:wrap;gap:7px;position:sticky;top:67px;z-index:19;box-shadow:0 2px 7px rgba(0,0,0,.05)}
.nav a{color:#17324d;padding:9px 12px;border-radius:8px;font-size:15px;background:#eef5ff;transition:.15s;border:1px solid #d8e6fb}.nav a:hover{transform:translateY(-1px);background:#e2efff}
.container{max-width:1250px;margin:20px auto;padding:0 14px}.card{background:#fff;border:1px solid #dbe2ea;border-radius:14px;padding:18px;margin-bottom:18px;box-shadow:0 3px 12px rgba(22,34,51,.05)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:11px}.field{display:flex;flex-direction:column;gap:5px}.field label{font-weight:700;font-size:13px;color:#374151}
input,select,textarea{width:100%;padding:10px 11px;border:1px solid #bfc9d6;border-radius:8px;font:inherit;background:#fff}textarea{min-height:80px;resize:vertical}
button,.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 14px;border:0;border-radius:8px;background:#1976d2;color:#fff;cursor:pointer;font:inherit}.btn.gray{background:#607d8b}.btn.green{background:#2e7d32}.btn.red{background:#c62828;color:#fff}.btn.arrears{background:#ffd54f;color:#000;border:1px solid #d4aa00;font-weight:800}.btn.share{background:#00897b;color:#fff}.btn.orange{background:#ef6c00}.btn.purple{background:#6a1b9a}.btn.dark{background:#263238}
.actions{display:flex;flex-wrap:wrap;gap:7px;align-items:center}.quick-actions .btn{font-size:15px;padding:12px 16px;font-weight:700}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:12px}.stat{background:#fff;border:1px solid #dbe2ea;border-radius:14px;padding:17px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.04)}.stat b{display:block;font-size:22px;margin-bottom:6px}.stat span{font-size:12px;color:#697586}
table{border-collapse:collapse;width:100%;background:#fff}th,td{border:1px solid #d2d9e1;padding:7px;text-align:center;font-size:13px}th{background:#edf3f8;font-weight:800}td .btn{font-size:12px;padding:6px 8px;margin:2px}.red{color:#d32f2f;font-weight:800}.green-text{color:#2e7d32;font-weight:800}.muted{color:#6b7280;font-size:12px}.flash{padding:12px 14px;border-radius:10px;margin-bottom:15px;font-weight:700}.flash.success{background:#e8f5e9;color:#1b5e20;border:1px solid #b7d8ba}.flash.warning{background:#fff3e0;color:#8a4500;border:1px solid #f2c48c}.flash.error{background:#ffebee;color:#a30016;border:1px solid #f0b6bf}
.footer{text-align:center;color:#697586;font-size:12px;padding:25px 10px 40px}.footer b{color:#334155}.notice{border-right:4px solid #1976d2;background:#f5f9ff;padding:11px 13px;border-radius:8px;margin-bottom:12px}
@media(max-width:700px){
 .topbar{padding:11px 12px;gap:8px}
 .brand{font-size:17px}
 .nav{position:static;padding:7px;overflow-x:auto;flex-wrap:nowrap;-webkit-overflow-scrolling:touch}
 .nav a{font-size:14px;padding:9px 11px;white-space:nowrap;flex:0 0 auto}
 .container{padding:0 9px;margin:12px auto}
 .card{padding:13px;border-radius:11px}
 th,td{font-size:11px;padding:5px}
 .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
 .table-wrap table{min-width:760px}
 .actions .btn,.actions button{flex:1 1 auto;min-width:120px;font-size:12px;padding:9px 10px}
 .grid{grid-template-columns:1fr}
 .stats{grid-template-columns:repeat(2,minmax(0,1fr))}
 .stat b{font-size:19px}
 input,select,textarea{font-size:16px}
}
</style>
"""


def page(request, title, body, show_nav=True):
    flash = get_flash(request)
    flash_html = ""
    if flash:
        flash_html = f'<div class="flash {esc(flash["level"])}">{esc(flash["message"])}</div>'

    nav = ""
    if show_nav:
        nav = """
        <div class="nav">
            <a href="/">🏠 الرئيسية</a>
            <a href="/subscribers">👥 المشتركين</a>
            <a href="/readings">📖 القراءات</a>
            <a href="/prices">💰 الأسعار</a>
            <a href="/invoices">🧾 الفواتير</a>
            <a href="/payments">💳 المدفوعات</a>
            <a href="/accounts">📊 حسابات المشتركين</a>
            <a href="/report-arrears">⚠️ المتأخرات</a>
            <a href="/expenses">💸 المصروفات</a>
            <a href="/employees">👨‍💼 الموظفين</a>
            <a href="/salaries">💵 الرواتب</a>
            <a href="/donations">🎁 التبرعات</a>
            <a href="/whatsapp">📱 واتساب</a>
            <a href="/reports">📑 التقارير</a>
            <a href="/backups">💾 النسخ الاحتياطية</a>
            <a href="/system-reset" class="btn red">⚠️ تهيئة النظام</a>
            <a href="/change-password">🔐 تغيير الرمز</a>
            <a href="/logout" class="btn red">🚪 خروج</a>
        </div>
    """

    footer = """
    <div class="footer">
        <div><b>برمجة وتصميم : ابو سعــــــــــــيد</b></div>
        <div>737698405 / 780722005</div>
    </div>
    """

    return f"""<!doctype html><html lang="ar" dir="rtl"><head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{esc(title)} - نظام مشروع الغميس</title>{GLOBAL_CSS}</head><body>
    <div class="topbar"><div class="brand">نظام مشروع الغميس<small>المياه والكهرباء والخدمات المالية</small></div><div>أهلًا بك</div></div>
    {nav}<main class="container">{flash_html}{body}</main>{footer}<script>
async function sharePdf(url, filename){{
  try{{
    const r=await fetch(url);
    if(!r.ok) throw new Error();
    const blob=await r.blob();
    const file=new File([blob],filename,{{type:"application/pdf"}});
    if(navigator.share && (!navigator.canShare || navigator.canShare({{files:[file]}}))){{
      await navigator.share({{title:filename,text:"مستند PDF - نظام مشروع الغميس",files:[file]}});
    }} else {{
      window.open(url,"_blank");
    }}
  }} catch(e) {{ window.open(url,"_blank"); }}
}}
</script></body></html>"""


# =========================================================
# الرئيسية وتسجيل الدخول
# =========================================================

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if request.cookies.get(AUTH_COOKIE) == AUTH_TOKEN:
        return RedirectResponse("/", 303)
    body = f"""
    <div class="card" style="max-width:480px;margin:50px auto">
        <h2 style="text-align:center">🔐 تسجيل الدخول</h2>
        <p class="muted" style="text-align:center">أدخل رمز الدخول للوصول إلى نظام مشروع الغميس.</p>
        <form method="post" action="/login" autocomplete="off">
            <div class="field"><label>رمز البرنامج</label><input name="password" type="password" required autofocus autocomplete="new-password" autocapitalize="none" spellcheck="false"></div>
            <br><button style="width:100%">دخول إلى البرنامج</button>
        </form>
    </div>
    """
    return page(request, "تسجيل الدخول", body, show_nav=False)


@app.post("/login")
def login(request: Request, password: str = Form(...)):
    c = get_connection()
    stored = c.execute("SELECT value FROM program_settings WHERE key='password_hash'").fetchone()
    c.close()
    if stored and verify_password(password, stored[0]):
        response = RedirectResponse("/", 303)
        response.set_cookie(AUTH_COOKIE, AUTH_TOKEN, httponly=True, secure=(request.url.scheme == "https"), samesite="lax", path="/")
        return response
    return HTMLResponse("<h2 style='font-family:Arial;text-align:center;margin-top:70px'>رمز الدخول غير صحيح<br><a href='/login'>عودة</a></h2>", status_code=401)


@app.get("/logout")
def logout(request: Request):
    response = RedirectResponse("/login", 303)
    response.delete_cookie(AUTH_COOKIE, path="/")
    return response


@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    c = get_connection()
    x = c.cursor()

    subscribers = x.execute(
        "SELECT COUNT(*) FROM subscribers"
    ).fetchone()[0]

    meters = x.execute(
        "SELECT COUNT(*) FROM meters"
    ).fetchone()[0]

    open_invoices = x.execute(
        "SELECT COUNT(*) FROM invoices WHERE closed=0"
    ).fetchone()[0]

    total_paid = x.execute(
        "SELECT COALESCE(SUM(amount),0) FROM payments"
    ).fetchone()[0]

    total_expenses = x.execute(
        "SELECT COALESCE(SUM(amount),0) FROM expenses"
    ).fetchone()[0]

    arrears_total = x.execute("""
        SELECT COALESCE(SUM(
            MAX(0,
                COALESCE(s.previous_arrears,0)
                + COALESCE((
                    SELECT SUM(r.consumption_value)
                    FROM readings r
                    JOIN meters m ON r.meter_id=m.id
                    WHERE m.subscriber_id=s.id
                ),0)
                - COALESCE((
                    SELECT SUM(p.amount)
                    FROM payments p
                    WHERE p.subscriber_id=s.id
                ),0)
            )
        ),0)
        FROM subscribers s
    """).fetchone()[0]

    c.close()

    body = f"""
    <div class="card">
        <h2>🏠 الرئيسية</h2>
        <p>لوحة التحكم لنظام المياه والكهرباء - مشروع الغميس</p>
    </div>

    <div class="stats">
        <div class="stat"><b>{subscribers}</b><span>👥 المشتركون</span></div>
        <div class="stat"><b>{meters}</b><span>🔢 العدادات</span></div>
        <div class="stat"><b>{open_invoices}</b><span>🧾 الفواتير المفتوحة</span></div>
        <div class="stat"><b>{money(total_paid)}</b><span>💳 إجمالي المدفوعات</span></div>
        <div class="stat"><b>{money(arrears_total)}</b><span>⚠️ إجمالي المتأخرات الحالية</span></div>
        <div class="stat"><b>{money(total_expenses)}</b><span>💸 إجمالي المصروفات</span></div>
    </div>

    <div class="card">
        <h3>الوصول السريع</h3>
        <div class="actions quick-actions">
            <a class="btn" href="/subscribers">👥 المشتركين</a>
            <a class="btn" href="/readings">📖 إدخال القراءات</a>
            <a class="btn green" href="/invoices">🧾 الفواتير</a>
            <a class="btn purple" href="/payments">💳 السداد</a>
            <a class="btn gray" href="/accounts">📊 حسابات المشتركين</a>
            <a class="btn arrears" href="/report-arrears">⚠️ تقرير المتأخرات</a>
            <a class="btn orange" href="/whatsapp">📱 واتساب</a>
        </div>
    </div>
    """
    return page(request, "الرئيسية", body)


@app.get("/change-password", response_class=HTMLResponse)
def change_password_page(request: Request):
    body = """
    <div class="card" style="max-width:600px;margin:auto">
        <h2>🔐 تغيير رمز البرنامج</h2>
        <form method="post" action="/change-password">
            <div class="grid">
                <div class="field"><label>الرمز الحالي</label><input name="old_password" type="password" required autocomplete="current-password"></div>
                <div class="field"><label>الرمز الجديد</label><input name="new_password" type="password" minlength="4" required autocomplete="new-password"></div>
                <div class="field"><label>تأكيد الرمز الجديد</label><input name="confirm_password" type="password" minlength="4" required autocomplete="new-password"></div>
            </div><br><button>حفظ الرمز الجديد</button>
        </form>
    </div>
    """
    return page(request, "تغيير الرمز", body)


@app.post("/change-password")
def change_password(request: Request, old_password: str = Form(...), new_password: str = Form(...), confirm_password: str = Form(...)):
    if new_password != confirm_password:
        set_flash(request, "تأكيد الرمز الجديد غير مطابق.", "error")
        return RedirectResponse("/change-password", 303)
    if len(new_password) < 4:
        set_flash(request, "الرمز الجديد يجب ألا يقل عن 4 أحرف أو أرقام.", "error")
        return RedirectResponse("/change-password", 303)
    c = get_connection(); x = c.cursor()
    row = x.execute("SELECT value FROM program_settings WHERE key='password_hash'").fetchone()
    if not row or not verify_password(old_password, row[0]):
        c.close()
        set_flash(request, "الرمز الحالي غير صحيح.", "error")
        return RedirectResponse("/change-password", 303)
    x.execute("UPDATE program_settings SET value=? WHERE key='password_hash'", (hash_password(new_password),))
    c.commit(); c.close()
    set_flash(request, "تم تغيير رمز البرنامج بنجاح.")
    return RedirectResponse("/", 303)


# =========================================================
# تهيئة النظام بالكامل
# =========================================================

RESETTABLE_TABLES = [
    "invoice_details",
    "readings",
    "payments",
    "invoices",
    "meters",
    "subscribers",
    "prices",
    "expenses",
    "employees",
    "salaries",
    "donations",
    "whatsapp_logs",
]

@app.get("/system-reset", response_class=HTMLResponse)
def system_reset_page(request: Request):
    body = """
    <div class="card" style="max-width:760px;margin:auto;border:2px solid #b91c1c">
        <h2 style="color:#b91c1c;text-align:center">⚠️ تهيئة نظام مشروع الغميس</h2>
        <div class="notice" style="background:#fff7ed;border-color:#fdba74;color:#9a3412;font-size:16px;line-height:1.9">
            <b>تحذير مهم:</b><br>
            هذا الإجراء سيحذف جميع بيانات التشغيل الحالية ويعيد أرقام السجلات التلقائية إلى البداية،
            وكأن النظام جديد تمامًا.<br>
            سيتم <b>الإبقاء على رمز دخول البرنامج</b> حتى لا تُفقد حماية النظام.<br>
            قبل التهيئة سيتم إنشاء <b>نسخة احتياطية تلقائية</b> من البيانات الحالية، حتى يمكن استعادتها عند الحاجة.
        </div>
        <form method="post" action="/system-reset" onsubmit="return confirm('⚠️ تأكيد نهائي\n\nسيتم حذف جميع المشتركين والعدادات والقراءات والفواتير والمدفوعات والأسعار والمصروفات والموظفين والرواتب والتبرعات والسجلات المرتبطة، ثم تصفير أرقامها التلقائية.\n\nهل أنت متأكد أنك تريد البدء من الصفر؟');">
            <div class="field">
                <label>للحماية: أدخل رمز البرنامج الحالي</label>
                <input name="password" type="password" required autocomplete="current-password" placeholder="رمز البرنامج">
            </div>
            <div class="field">
                <label>اكتب كلمة التحقق: تهيئة النظام</label>
                <input name="confirmation" required autocomplete="off" placeholder="تهيئة النظام">
            </div>
            <br>
            <div class="actions">
                <button class="btn red" type="submit">⚠️ تهيئة النظام والبدء من الصفر</button>
                <a class="btn gray" href="/">إلغاء والعودة للرئيسية</a>
            </div>
        </form>
    </div>
    """
    return page(request, "تهيئة النظام", body)


@app.post("/system-reset")
def system_reset(
    request: Request,
    password: str = Form(...),
    confirmation: str = Form(...),
):
    if confirmation.strip() != "تهيئة النظام":
        set_flash(request, "لم يتم تنفيذ التهيئة: كلمة التحقق غير صحيحة.", "error")
        return RedirectResponse("/system-reset", 303)

    # التحقق من رمز البرنامج قبل السماح بأي حذف.
    c = get_connection()
    row = c.execute("SELECT value FROM program_settings WHERE key='password_hash'").fetchone()
    c.close()
    if not row or not verify_password(password, row[0]):
        set_flash(request, "لم يتم تنفيذ التهيئة: رمز البرنامج غير صحيح.", "error")
        return RedirectResponse("/system-reset", 303)

    # إنشاء نسخة احتياطية تلقائية قبل الحذف.
    try:
        backup_path = create_safe_backup()
    except Exception as e:
        set_flash(request, f"تم إلغاء التهيئة حفاظًا على البيانات، لأن النسخة الاحتياطية لم تُنشأ: {e}", "error")
        return RedirectResponse("/system-reset", 303)

    c = get_connection()
    foreign_keys_disabled = False
    try:
        # نوقف فحص العلاقات مؤقتًا أثناء التهيئة.
        # السبب: توجد جداول مرتبطة ببعضها، وقد تختلف ترتيب العلاقات في قواعد
        # البيانات التي تم إنشاؤها بإصدارات سابقة من البرنامج.
        # هذا لا يؤثر على العمل الطبيعي؛ نعيد تشغيله بعد الانتهاء ونتحقق من سلامة القاعدة.
        c.execute("PRAGMA foreign_keys=OFF")
        foreign_keys_disabled = True
        c.execute("BEGIN")

        # حذف الجداول التابعة أولًا ثم الجداول الأساسية.
        for table in RESETTABLE_TABLES:
            c.execute(f"DELETE FROM {table}")

        # تصفير العدادات التلقائية حتى يبدأ أول سجل جديد من الرقم 1.
        placeholders = ",".join("?" for _ in RESETTABLE_TABLES)
        c.execute(
            f"DELETE FROM sqlite_sequence WHERE name IN ({placeholders})",
            RESETTABLE_TABLES,
        )

        c.commit()

        # إعادة حماية العلاقات بعد نجاح التهيئة.
        c.execute("PRAGMA foreign_keys=ON")
        foreign_keys_disabled = False

        # فحص نهائي للتأكد من عدم وجود علاقات مكسورة.
        fk_errors = c.execute("PRAGMA foreign_key_check").fetchall()
        if fk_errors:
            raise RuntimeError("تمت التهيئة لكن فحص العلاقات أظهر مشكلة في قاعدة البيانات.")

    except Exception as e:
        try:
            if c.in_transaction:
                c.rollback()
        except Exception:
            pass
        try:
            if foreign_keys_disabled:
                c.execute("PRAGMA foreign_keys=ON")
        except Exception:
            pass
        c.close()
        set_flash(request, f"فشلت تهيئة النظام وتم التراجع عن العملية. البيانات لم تُحذف. السبب: {e}", "error")
        return RedirectResponse("/system-reset", 303)
    finally:
        try:
            c.close()
        except Exception:
            pass

    set_flash(request, f"تمت تهيئة النظام بنجاح والبدء من الصفر. تم حفظ نسخة احتياطية قبل التهيئة: {backup_path.name}", "success")
    return RedirectResponse("/", 303)


# =========================================================
# النسخ الاحتياطي الآمن وإدارته
# =========================================================

def create_safe_backup():
    """إنشاء نسخة SQLite سليمة باستخدام SQLite Online Backup بدل نسخ الملف الخام."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")
    dest = BACKUP_DIR / f"database_backup_{timestamp}.db"
    source = Path(DB_NAME)

    if not source.exists():
        raise FileNotFoundError("قاعدة البيانات غير موجودة")

    src = sqlite3.connect(str(source), timeout=30)
    dst = sqlite3.connect(str(dest), timeout=30)
    try:
        src.execute("PRAGMA wal_checkpoint(PASSIVE)")
        src.backup(dst)
        dst.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        check = dst.execute("PRAGMA integrity_check").fetchone()
        if not check or str(check[0]).lower() != "ok":
            raise RuntimeError("فشل فحص سلامة النسخة الاحتياطية")
        dst.commit()
    finally:
        dst.close()
        src.close()

    return dest


def backup_files():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(
        [p for p in BACKUP_DIR.glob("database_backup_*.db") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )


@app.post("/backup")
def backup(request: Request):
    try:
        dest = create_safe_backup()
        set_flash(request, f"تم إنشاء نسخة احتياطية آمنة بنجاح: {dest.name}")
    except Exception as e:
        set_flash(request, f"تعذر إنشاء النسخة الاحتياطية: {e}", "error")
    return RedirectResponse("/backups", 303)


@app.get("/backup")
def backup_get(request: Request):
    # توافق مع أي رابط قديم للنسخ الاحتياطي.
    return RedirectResponse("/backups", 303)


@app.get("/backups", response_class=HTMLResponse)
def backups_page(request: Request):
    files = backup_files()
    rows = []
    for f in files:
        try:
            size_kb = f.stat().st_size / 1024
            created = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            rows.append(f"""
            <tr>
                <td>{esc(f.name)}</td>
                <td>{created}</td>
                <td>{size_kb:,.1f} KB</td>
                <td class="actions">
                    <a class="btn" href="/backup/download/{quote(f.name)}">⬇️ تنزيل</a>
                    <form method="post" action="/backup/restore" style="display:inline" onsubmit="return confirm('سيتم استبدال قاعدة البيانات الحالية بهذه النسخة. هل أنت متأكد؟')">
                        <input type="hidden" name="filename" value="{esc(f.name)}">
                        <button class="btn orange" type="submit">♻️ استعادة</button>
                    </form>
                    <form method="post" action="/backup/delete" style="display:inline" onsubmit="return confirm('حذف هذه النسخة الاحتياطية نهائيًا؟')">
                        <input type="hidden" name="filename" value="{esc(f.name)}">
                        <button class="btn red" type="submit">🗑️ حذف</button>
                    </form>
                </td>
            </tr>
            """)
        except OSError:
            continue

    table = "".join(rows) or """
        <tr><td colspan="4" class="muted">لا توجد نسخ احتياطية محفوظة حتى الآن.</td></tr>
    """

    body = f"""
    <div class="card">
        <h2>💾 إدارة النسخ الاحتياطية</h2>
        <div class="notice">
            يتم إنشاء النسخة باستخدام آلية SQLite الآمنة، وتُحفظ كل نسخة بتاريخ ووقت مستقل
            دون استبدال النسخ السابقة.
        </div>
        <div class="actions">
            <form method="post" action="/backup" onsubmit="return confirm('إنشاء نسخة احتياطية آمنة الآن؟')">
                <button class="btn green" type="submit">💾 إنشاء نسخة جديدة</button>
            </form>
            <a class="btn gray" href="/">↩️ الرئيسية</a>
        </div>
    </div>

    <div class="card table-wrap">
        <h3>النسخ المحفوظة ({len(files)})</h3>
        <table>
            <tr><th>اسم النسخة</th><th>التاريخ والوقت</th><th>الحجم</th><th>الإجراء</th></tr>
            {table}
        </table>
    </div>
    """
    return page(request, "النسخ الاحتياطية", body)


@app.get("/backup/download/{filename}")
def backup_download(request: Request, filename: str):
    name = Path(filename).name
    target = BACKUP_DIR / name
    if not name.startswith("database_backup_") or target.suffix.lower() != ".db" or not target.is_file():
        return HTMLResponse("<h2 style='text-align:center'>النسخة الاحتياطية غير موجودة.</h2>", status_code=404)
    return FileResponse(
        str(target),
        media_type="application/octet-stream",
        filename=target.name
    )


@app.post("/backup/delete")
def backup_delete(request: Request, filename: str = Form(...)):
    name = Path(filename).name
    target = BACKUP_DIR / name
    if not name.startswith("database_backup_") or target.suffix.lower() != ".db":
        set_flash(request, "اسم النسخة الاحتياطية غير صالح.", "error")
        return RedirectResponse("/backups", 303)
    try:
        if not target.is_file():
            raise FileNotFoundError("النسخة غير موجودة")
        target.unlink()
        set_flash(request, f"تم حذف النسخة الاحتياطية: {name}", "warning")
    except Exception as e:
        set_flash(request, f"تعذر حذف النسخة: {e}", "error")
    return RedirectResponse("/backups", 303)


@app.post("/backup/restore")
def backup_restore(request: Request, filename: str = Form(...)):
    name = Path(filename).name
    source = BACKUP_DIR / name
    temp = BACKUP_DIR / f".restore_{secrets.token_hex(8)}.db"

    if not name.startswith("database_backup_") or source.suffix.lower() != ".db" or not source.is_file():
        set_flash(request, "النسخة الاحتياطية غير صالحة.", "error")
        return RedirectResponse("/backups", 303)

    try:
        # فحص النسخة أولًا قبل لمس قاعدة البيانات الحالية.
        check_conn = sqlite3.connect(str(source), timeout=30)
        try:
            check = check_conn.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                raise RuntimeError("فشل فحص سلامة النسخة الاحتياطية")
        finally:
            check_conn.close()

        # تجهيز نسخة مؤقتة، ثم استبدال قاعدة البيانات في عملية واحدة.
        src = sqlite3.connect(str(source), timeout=30)
        dst = sqlite3.connect(str(temp), timeout=30)
        try:
            src.backup(dst)
            check = dst.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                raise RuntimeError("فشل فحص النسخة بعد التجهيز")
            dst.commit()
        finally:
            dst.close()
            src.close()

        # احتفظ بنسخة من الحالة الحالية قبل الاستعادة.
        current_backup = create_safe_backup()

        os.replace(str(temp), DB_NAME)

        # ملفات WAL/SHM القديمة لا ينبغي أن تبقى مرتبطة بقاعدة البيانات الجديدة.
        for suffix in ("-wal", "-shm"):
            sidecar = Path(str(DB_NAME) + suffix)
            try:
                if sidecar.exists():
                    sidecar.unlink()
            except OSError:
                pass

        set_flash(
            request,
            f"تمت استعادة النسخة بنجاح. تم أيضًا حفظ نسخة من الحالة السابقة باسم: {current_backup.name}",
            "success"
        )
    except Exception as e:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
        set_flash(request, f"تعذر استعادة النسخة الاحتياطية: {e}", "error")

    return RedirectResponse("/backups", 303)


# =========================================================
# المشتركين
# =========================================================

@app.get("/subscribers", response_class=HTMLResponse)
def subscribers_page(request: Request):
    c=get_connection(); rows=c.execute("SELECT * FROM subscribers ORDER BY id").fetchall(); c.close()
    table = "".join(f"""
    <tr><td>{r['id']}</td><td>{esc(r['name'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['address'])}</td>
    <td class="red">{money(r['previous_arrears'])}</td><td>{esc(r['notes'])}</td><td>
    <a class="btn gray" href="/meters/{r['id']}">العدادات</a>
    <a class="btn" href="/account/{r['id']}">الحساب</a>
    <a class="btn orange" href="/edit-subscriber/{r['id']}">تعديل</a>
    <a class="btn red" href="/delete-subscriber/{r['id']}" onclick="return confirm('حذف المشترك وجميع بياناته؟')">حذف</a>
    </td></tr>""" for r in rows)
    body=f"""
    <div class="card"><h2>👥 المشتركين</h2>
    <form method="post" action="/save-subscriber"><div class="grid">
      <div class="field"><label>اسم المشترك</label><input name="name" required></div>
      <div class="field"><label>رقم الهاتف</label><input name="phone"></div>
      <div class="field"><label>العنوان</label><input name="address"></div>
      <div class="field"><label>المتأخرات الأولية</label><input name="previous_arrears" type="number" step=".01" value="0"></div>
      <div class="field"><label>ملاحظات</label><input name="notes"></div>
    </div><br><button>💾 حفظ المشترك</button></form></div>
    <div class="card table-wrap"><table><tr><th>رقم</th><th>الاسم</th><th>الهاتف</th><th>العنوان</th><th>المتأخرات الأولية</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div>
    """
    return page(request,"المشتركين",body)


@app.post("/save-subscriber")
def save_subscriber(request: Request, name: str=Form(...), phone: str=Form(""), address: str=Form(""), previous_arrears: float=Form(0), notes: str=Form("")):
    c=get_connection(); c.execute("INSERT INTO subscribers(name,phone,address,previous_arrears,notes) VALUES(?,?,?,?,?)",(name,phone,address,previous_arrears,notes)); c.commit(); c.close()
    set_flash(request,"تم حفظ المشترك بنجاح.")
    return RedirectResponse("/subscribers",303)


@app.get("/edit-subscriber/{subscriber_id}", response_class=HTMLResponse)
def edit_subscriber(request: Request, subscriber_id:int):
    c=get_connection(); r=c.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone(); c.close()
    if not r:return HTMLResponse("<h2>المشترك غير موجود</h2>")
    body=f"""
    <div class="card"><h2>تعديل المشترك</h2><form method="post" action="/update-subscriber/{r['id']}">
    <div class="grid"><div class="field"><label>اسم المشترك</label><input name="name" value="{esc(r['name'])}" required></div>
    <div class="field"><label>الهاتف</label><input name="phone" value="{esc(r['phone'])}"></div>
    <div class="field"><label>العنوان</label><input name="address" value="{esc(r['address'])}"></div>
    <div class="field"><label>المتأخرات الأولية</label><input name="previous_arrears" type="number" step=".01" value="{r['previous_arrears'] or 0}"></div>
    <div class="field"><label>ملاحظات</label><input name="notes" value="{esc(r['notes'])}"></div></div><br><button>حفظ التعديل</button> <a class="btn gray" href="/subscribers">عودة</a></form></div>"""
    return page(request,"تعديل المشترك",body)


@app.post("/update-subscriber/{subscriber_id}")
def update_subscriber(request: Request, subscriber_id:int,name:str=Form(...),phone:str=Form(""),address:str=Form(""),previous_arrears:float=Form(0),notes:str=Form("")):
    c=get_connection(); c.execute("UPDATE subscribers SET name=?,phone=?,address=?,previous_arrears=?,notes=? WHERE id=?",(name,phone,address,previous_arrears,notes,subscriber_id)); c.commit(); c.close()
    set_flash(request,"تم تعديل بيانات المشترك.")
    return RedirectResponse("/subscribers",303)


@app.get("/delete-subscriber/{subscriber_id}")
def delete_subscriber(request: Request, subscriber_id:int):
    c=get_connection(); x=c.cursor()
    mids=[r[0] for r in x.execute("SELECT id FROM meters WHERE subscriber_id=?",(subscriber_id,)).fetchall()]
    for mid in mids:
        x.execute("DELETE FROM readings WHERE meter_id=?",(mid,))
        x.execute("DELETE FROM invoice_details WHERE meter_id=?",(mid,))
    invs=[r[0] for r in x.execute("SELECT id FROM invoices WHERE subscriber_id=?",(subscriber_id,)).fetchall()]
    for iid in invs:
        x.execute("DELETE FROM payments WHERE invoice_id=?",(iid,))
        x.execute("DELETE FROM invoice_details WHERE invoice_id=?",(iid,))
    x.execute("DELETE FROM whatsapp_logs WHERE subscriber_id=?",(subscriber_id,))
    x.execute("DELETE FROM meters WHERE subscriber_id=?",(subscriber_id,))
    x.execute("DELETE FROM invoices WHERE subscriber_id=?",(subscriber_id,))
    x.execute("DELETE FROM subscribers WHERE id=?",(subscriber_id,))
    c.commit(); c.close(); set_flash(request,"تم حذف المشترك وبياناته.","warning")
    return RedirectResponse("/subscribers",303)


# =========================================================
# العدادات
# =========================================================

@app.get("/meters/{subscriber_id}", response_class=HTMLResponse)
def meters_page(request: Request, subscriber_id:int):
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT id,name FROM subscribers WHERE id=?",(subscriber_id,)).fetchone()
    if not s:c.close(); return HTMLResponse("<h2>المشترك غير موجود</h2>")
    ms=x.execute("SELECT * FROM meters WHERE subscriber_id=? ORDER BY id",(subscriber_id,)).fetchall(); c.close()
    rows="".join(f"""<tr><td>{m['id']}</td><td>{esc(m['meter_type'])}</td><td>{esc(m['actual_meter_number'])}</td><td>{esc(m['status'])}</td><td>{esc(m['notes'])}</td><td>
    <a class="btn orange" href="/edit-meter/{m['id']}">تعديل</a><a class="btn red" href="/delete-meter/{m['id']}" onclick="return confirm('حذف العداد؟')">حذف</a></td></tr>""" for m in ms)
    body=f"""
    <div class="card"><h2>🔢 عدادات المشترك: {esc(s['name'])}</h2><form method="post" action="/save-meter"><input type="hidden" name="subscriber_id" value="{subscriber_id}">
    <div class="grid"><div class="field"><label>نوع العداد</label><select name="meter_type"><option>ماء 1</option><option>ماء 2</option><option>كهرباء 1</option><option>كهرباء 2</option></select></div>
    <div class="field"><label>رقم العداد الفعلي</label><input name="actual_meter_number"></div>
    <div class="field"><label>الحالة</label><select name="status"><option>يعمل</option><option>عطلان</option></select></div>
    <div class="field"><label>ملاحظات</label><input name="notes"></div></div><br><button>💾 حفظ العداد</button></form></div>
    <div class="card table-wrap"><table><tr><th>رقم</th><th>النوع</th><th>الفعلي</th><th>الحالة</th><th>ملاحظات</th><th>الإجراء</th></tr>{rows}</table></div>"""
    return page(request,"العدادات",body)


@app.post("/save-meter")
def save_meter(request: Request, subscriber_id:int=Form(...),meter_type:str=Form(...),actual_meter_number:str=Form(""),status:str=Form("يعمل"),notes:str=Form("")):
    c=get_connection(); c.execute("INSERT INTO meters(subscriber_id,meter_type,actual_meter_number,status,notes) VALUES(?,?,?,?,?)",(subscriber_id,meter_type,actual_meter_number,status,notes)); c.commit(); c.close(); set_flash(request,"تم حفظ العداد.")
    return RedirectResponse(f"/meters/{subscriber_id}",303)


@app.get("/edit-meter/{meter_id}", response_class=HTMLResponse)
def edit_meter(request: Request,meter_id:int):
    c=get_connection(); r=c.execute("SELECT * FROM meters WHERE id=?",(meter_id,)).fetchone(); c.close()
    if not r:return HTMLResponse("<h2>العداد غير موجود</h2>")
    opts="".join(f'<option {"selected" if r["meter_type"]==t else ""}>{t}</option>' for t in ["ماء 1","ماء 2","كهرباء 1","كهرباء 2"])
    body=f"""<div class="card"><h2>تعديل العداد</h2><form method="post" action="/update-meter/{r['id']}"><input type="hidden" name="subscriber_id" value="{r['subscriber_id']}">
    <div class="grid"><select name="meter_type">{opts}</select><input name="actual_meter_number" value="{esc(r['actual_meter_number'])}">
    <select name="status"><option {"selected" if r['status']=='يعمل' else ''}>يعمل</option><option {"selected" if r['status']=='عطلان' else ''}>عطلان</option></select><input name="notes" value="{esc(r['notes'])}"></div><br><button>حفظ</button></form></div>"""
    return page(request,"تعديل العداد",body)


@app.post("/update-meter/{meter_id}")
def update_meter(request: Request,meter_id:int,subscriber_id:int=Form(...),meter_type:str=Form(...),actual_meter_number:str=Form(""),status:str=Form("يعمل"),notes:str=Form("")):
    c=get_connection(); c.execute("UPDATE meters SET meter_type=?,actual_meter_number=?,status=?,notes=? WHERE id=?",(meter_type,actual_meter_number,status,notes,meter_id)); c.commit(); c.close(); set_flash(request,"تم تعديل العداد.")
    return RedirectResponse(f"/meters/{subscriber_id}",303)


@app.get("/delete-meter/{meter_id}")
def delete_meter(request: Request,meter_id:int):
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT subscriber_id FROM meters WHERE id=?",(meter_id,)).fetchone()
    if r:
        x.execute("DELETE FROM readings WHERE meter_id=?",(meter_id,))
        x.execute("DELETE FROM invoice_details WHERE meter_id=?",(meter_id,))
        x.execute("DELETE FROM meters WHERE id=?",(meter_id,))
        c.commit()
    c.close(); set_flash(request,"تم حذف العداد.","warning")
    return RedirectResponse(f"/meters/{r[0]}" if r else "/subscribers",303)


# =========================================================
# الأسعار
# =========================================================

@app.get("/prices", response_class=HTMLResponse)
def prices_page(request: Request):
    c=get_connection(); rows=c.execute("SELECT * FROM prices ORDER BY meter_type,start_date DESC,id DESC").fetchall(); c.close()
    table="".join(f"""<tr><td>{r['id']}</td><td>{esc(r['meter_type'])}</td><td>{money(r['unit_price'])}</td><td>{r['start_date']}</td><td>{'فعال' if r['active'] else 'غير فعال'}</td><td>{esc(r['notes'])}</td><td>
    <a class="btn orange" href="/edit-price/{r['id']}">تعديل</a><a class="btn red" href="/delete-price/{r['id']}" onclick="return confirm('حذف السعر؟')">حذف</a></td></tr>""" for r in rows)
    body=f"""<div class="card"><h2>💰 إدارة الأسعار</h2><form method="post" action="/save-price"><div class="grid">
    <select name="meter_type"><option>ماء 1</option><option>ماء 2</option><option>كهرباء 1</option><option>كهرباء 2</option></select>
    <input name="unit_price" type="number" step=".01" placeholder="سعر الوحدة" required><input name="start_date" type="date" required>
    <select name="active"><option value="1">فعال</option><option value="0">غير فعال</option></select><input name="notes" placeholder="ملاحظات"></div><br><button>💾 حفظ السعر</button></form></div>
    <div class="card table-wrap"><table><tr><th>رقم</th><th>النوع</th><th>السعر</th><th>البداية</th><th>الحالة</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div>"""
    return page(request,"الأسعار",body)


@app.post("/save-price")
def save_price(request: Request,meter_type:str=Form(...),unit_price:float=Form(...),start_date:str=Form(...),active:int=Form(1),notes:str=Form("")):
    c=get_connection(); c.execute("INSERT INTO prices(meter_type,unit_price,start_date,active,notes) VALUES(?,?,?,?,?)",(meter_type,unit_price,start_date,active,notes)); c.commit(); c.close(); set_flash(request,"تم حفظ السعر.")
    return RedirectResponse("/prices",303)


@app.get("/edit-price/{price_id}", response_class=HTMLResponse)
def edit_price(request: Request,price_id:int):
    c=get_connection(); p=c.execute("SELECT * FROM prices WHERE id=?",(price_id,)).fetchone(); c.close()
    if not p:return HTMLResponse("<h2>السعر غير موجود</h2>")
    opts="".join(f'<option {"selected" if p["meter_type"]==t else ""}>{t}</option>' for t in ["ماء 1","ماء 2","كهرباء 1","كهرباء 2"])
    body=f"""<div class="card"><h2>تعديل السعر</h2><form method="post" action="/update-price/{p['id']}"><div class="grid"><select name="meter_type">{opts}</select><input name="unit_price" type="number" step=".01" value="{p['unit_price']}" required><input name="start_date" type="date" value="{p['start_date']}" required><select name="active"><option value="1" {"selected" if p['active'] else ''}>فعال</option><option value="0" {"selected" if not p['active'] else ''}>غير فعال</option></select><input name="notes" value="{esc(p['notes'])}"></div><br><button>حفظ</button></form></div>"""
    return page(request,"تعديل السعر",body)


@app.post("/update-price/{price_id}")
def update_price(request: Request,price_id:int,meter_type:str=Form(...),unit_price:float=Form(...),start_date:str=Form(...),active:int=Form(1),notes:str=Form("")):
    c=get_connection(); c.execute("UPDATE prices SET meter_type=?,unit_price=?,start_date=?,active=?,notes=? WHERE id=?",(meter_type,unit_price,start_date,active,notes,price_id)); c.commit(); c.close(); set_flash(request,"تم تعديل السعر.")
    return RedirectResponse("/prices",303)


@app.get("/delete-price/{price_id}")
def delete_price(request: Request,price_id:int):
    c=get_connection(); c.execute("DELETE FROM prices WHERE id=?",(price_id,)); c.commit(); c.close(); set_flash(request,"تم حذف السعر.","warning")
    return RedirectResponse("/prices",303)


# =========================================================
# القراءات — منطق عدم تكرار الفواتير
# =========================================================

@app.get("/readings", response_class=HTMLResponse)
def readings_page(request: Request):
    c=get_connection(); x=c.cursor()
    meters=x.execute("""
        SELECT m.id,m.subscriber_id,s.name,m.meter_type,m.actual_meter_number
        FROM meters m JOIN subscribers s ON m.subscriber_id=s.id
        ORDER BY s.id,m.id
    """).fetchall()
    readings=x.execute("""
        SELECT r.*,s.name,m.meter_type,i.id AS invoice_number
        FROM readings r JOIN meters m ON r.meter_id=m.id
        JOIN subscribers s ON m.subscriber_id=s.id
        LEFT JOIN invoices i ON r.invoice_id=i.id
        ORDER BY r.id DESC
    """).fetchall()
    opts=""
    for m in meters:
        last=latest_reading(x,m['id'])
        prev=float(last['current_reading'] or 0) if last else 0
        open_iid=get_open_invoice_id(x,m['subscriber_id'])
        label=f"{m['name']} - {m['meter_type']} - عداد {m['actual_meter_number'] or ''} - السابقة: {prev}"
        if open_iid:
            label += f" - فاتورة مفتوحة {open_iid}"
        opts += f'<option value="{m["id"]}" data-previous="{prev}" data-open-invoice="{open_iid or ""}">{esc(label)}</option>'
    c.close()
    rows="".join(f"""<tr><td>{r['id']}</td><td>{esc(r['name'])}</td><td>{esc(r['meter_type'])}</td><td>{r['reading_date']}</td><td>{r['previous_reading']}</td><td><b>{r['current_reading']}</b></td><td><b>{r['consumption']}</b></td><td>{money(r['unit_price'])}</td><td>{money(r['consumption_value'])}</td><td>{r['invoice_number'] or '-'}</td><td>{esc(r['notes'])}</td><td><a class="btn orange" href="/edit-reading/{r['id']}">تعديل</a><a class="btn red" href="/delete-reading/{r['id']}" onclick="return confirm('حذف القراءة؟')">حذف</a></td></tr>""" for r in readings)
    body=f"""
    <div class="card"><h2>📖 إدخال القراءات</h2>
    <div class="notice">عند اختيار عداد له فاتورة مفتوحة، ستذهب القراءة إلى <b>نفس الفاتورة</b> ولن يتم إنشاء فاتورة ثانية.</div>
    <form method="post" action="/save-reading"><div class="grid">
      <div class="field"><label>العداد</label><select id="meter_id" name="meter_id" required><option value="">اختر العداد</option>{opts}</select></div>
      <div class="field"><label>تاريخ القراءة</label><input name="reading_date" type="date" value="{date.today().isoformat()}" required></div>
      <div class="field"><label>القراءة السابقة <span class="muted">(قابلة للكتابة)</span></label><input id="previous_reading" name="previous_reading" type="number" step=".01" value="0" inputmode="decimal" placeholder="اكتب السابقة للعداد الجديد إذا لزم"></div>
      <div class="field"><label>القراءة الحالية</label><input name="current_reading" type="number" step=".01" required></div>
      <div class="field"><label>ملاحظات</label><input name="notes" placeholder="ملاحظات"></div>
    </div><br><button>💾 حفظ القراءة</button></form></div>
    <div class="card table-wrap"><table><tr><th>رقم</th><th>المشترك</th><th>النوع</th><th>التاريخ</th><th>السابقة</th><th>الحالية</th><th>الاستهلاك</th><th>السعر</th><th>القيمة</th><th>الفاتورة</th><th>ملاحظات</th><th>الإجراء</th></tr>{rows}</table></div>
    <script>
    const meter=document.getElementById('meter_id'); const prev=document.getElementById('previous_reading');
    meter.onchange=function(){{const o=this.options[this.selectedIndex];prev.value=o.dataset.previous||0;}};
    </script>
    """
    return page(request,"القراءات",body)


@app.post("/save-reading")
def save_reading(request: Request,meter_id:int=Form(...),reading_date:str=Form(...),previous_reading:float=Form(0),current_reading:float=Form(...),notes:str=Form("")):
    c=get_connection(); x=c.cursor()
    m=x.execute("SELECT meter_type,subscriber_id FROM meters WHERE id=?",(meter_id,)).fetchone()
    if not m:
        c.close(); set_flash(request,"العداد غير موجود.","error"); return RedirectResponse("/readings",303)
    last=latest_reading(x,meter_id)
    # إذا كان العداد جديدًا ولا توجد له قراءة محفوظة، نعتمد القراءة السابقة
    # التي أدخلها المستخدم يدويًا. أما العداد الذي لديه قراءة سابقة فنستخدم
    # آخر قراءة حالية محفوظة له لضمان تسلسل القراءات.
    prev = float(last['current_reading'] or 0) if last else float(previous_reading or 0)
    if current_reading < prev:
        c.close(); set_flash(request,f"القراءة الحالية أقل من السابقة ({prev}).", "error"); return RedirectResponse("/readings",303)
    # لا تسمح بقراءتين لنفس العداد داخل نفس الفاتورة المفتوحة.
    open_iid=get_open_invoice_id(x,m['subscriber_id'])
    if open_iid:
        exists=x.execute("SELECT id FROM readings WHERE meter_id=? AND invoice_id=? LIMIT 1",(meter_id,open_iid)).fetchone()
        if exists:
            c.close(); set_flash(request,f"يوجد بالفعل قراءة لهذا العداد داخل الفاتورة المفتوحة رقم {open_iid}. استخدم تعديل القراءة بدل إنشاء قراءة جديدة.","warning"); return RedirectResponse("/readings",303)
    price=price_for_date(x,m['meter_type'],reading_date)
    if price is None:
        c.close(); set_flash(request,"لا يوجد سعر فعال مناسب لتاريخ القراءة.","error"); return RedirectResponse("/prices",303)
    if open_iid is None:
        open_iid=new_invoice_for_reading(x,m['subscriber_id'],reading_date)
        msg=f"تم حفظ القراءة وإنشاء الفاتورة رقم {open_iid} للمشترك."
    else:
        msg=f"يوجد فاتورة مفتوحة رقم {open_iid}. تم ربط القراءة بها ولن يتم إنشاء فاتورة جديدة."
    cons=current_reading-prev; val=cons*price
    x.execute("""
        INSERT INTO readings(meter_id,reading_date,previous_reading,current_reading,consumption,unit_price,consumption_value,notes,invoice_id)
        VALUES(?,?,?,?,?,?,?,?,?)
    """,(meter_id,reading_date,prev,current_reading,cons,price,val,notes,open_iid))
    build_invoice(x,m['subscriber_id'],open_iid)
    c.commit(); c.close(); set_flash(request,msg)
    return RedirectResponse("/readings",303)


@app.get("/edit-reading/{reading_id}", response_class=HTMLResponse)
def edit_reading(request: Request,reading_id:int):
    c=get_connection(); r=c.execute("""
        SELECT r.*,s.name,m.meter_type,i.id AS invoice_number,i.closed AS invoice_closed
        FROM readings r JOIN meters m ON r.meter_id=m.id JOIN subscribers s ON m.subscriber_id=s.id
        LEFT JOIN invoices i ON r.invoice_id=i.id WHERE r.id=?
    """,(reading_id,)).fetchone(); c.close()
    if not r:return HTMLResponse("<h2>القراءة غير موجودة</h2>")
    note = "<div class='notice'>هذه القراءة مرتبطة بفاتورة مغلقة؛ تعديلها لن يعيد فتح الفاتورة تلقائيًا.</div>" if r['invoice_closed'] else ""
    body=f"""<div class="card"><h2>تعديل القراءة</h2>{note}<p>المشترك: <b>{esc(r['name'])}</b> | العداد: <b>{esc(r['meter_type'])}</b> | الفاتورة: <b>{r['invoice_number'] or '-'}</b></p>
    <form method="post" action="/update-reading/{r['id']}"><div class="grid"><input name="reading_date" type="date" value="{r['reading_date']}" required><input name="previous_reading" type="number" step=".01" value="{r['previous_reading']}" required><input name="current_reading" type="number" step=".01" value="{r['current_reading']}" required><input name="notes" value="{esc(r['notes'])}"></div><br><button>حفظ التعديل</button><a class="btn gray" href="/readings">عودة</a></form></div>"""
    return page(request,"تعديل القراءة",body)


@app.post("/update-reading/{reading_id}")
def update_reading(request: Request,reading_id:int,reading_date:str=Form(...),previous_reading:float=Form(...),current_reading:float=Form(...),notes:str=Form("")):
    if current_reading < previous_reading:
        set_flash(request,"القراءة الحالية لا يمكن أن تكون أقل من السابقة.","error"); return RedirectResponse("/readings",303)
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT * FROM readings WHERE id=?",(reading_id,)).fetchone()
    if not r:
        c.close(); set_flash(request,"القراءة غير موجودة.","error"); return RedirectResponse("/readings",303)
    mt=x.execute("SELECT meter_type,subscriber_id FROM meters WHERE id=?",(r['meter_id'],)).fetchone()
    price=price_for_date(x,mt['meter_type'],reading_date)
    if price is None:
        c.close(); set_flash(request,"لا يوجد سعر مناسب لتاريخ القراءة.","error"); return RedirectResponse("/prices",303)
    new_cons=current_reading-previous_reading; new_val=new_cons*price
    x.execute("UPDATE readings SET reading_date=?,previous_reading=?,current_reading=?,consumption=?,unit_price=?,consumption_value=?,notes=? WHERE id=?",(reading_date,previous_reading,current_reading,new_cons,price,new_val,notes,reading_id))
    if r['invoice_id']:
        inv=x.execute("SELECT closed FROM invoices WHERE id=?",(r['invoice_id'],)).fetchone()
        if inv and not inv['closed']:
            build_invoice(x,mt['subscriber_id'],r['invoice_id'])
    c.commit(); c.close(); set_flash(request,"تم تعديل القراءة وتحديث الفاتورة المفتوحة إن وجدت.")
    return RedirectResponse("/readings",303)


@app.get("/delete-reading/{reading_id}")
def delete_reading(request: Request,reading_id:int):
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT * FROM readings WHERE id=?",(reading_id,)).fetchone()
    if not r:
        c.close(); return RedirectResponse("/readings",303)
    subscriber=x.execute("SELECT subscriber_id FROM meters WHERE id=?",(r['meter_id'],)).fetchone()
    x.execute("DELETE FROM readings WHERE id=?",(reading_id,))
    if r['invoice_id']:
        inv=x.execute("SELECT closed FROM invoices WHERE id=?",(r['invoice_id'],)).fetchone()
        if inv and not inv['closed']:
            build_invoice(x,subscriber[0],r['invoice_id'])
    c.commit(); c.close(); set_flash(request,"تم حذف القراءة.","warning")
    return RedirectResponse("/readings",303)


# =========================================================
# تصميم الفاتورة — 3 فواتير A4 مع خطوط أوضح
# =========================================================

INVOICE_CSS = """
<style>
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:Arial,Tahoma,sans-serif;direction:rtl;background:#e3e7eb;color:#17202a}
.invoice{width:100%;max-width:198mm;margin:0 auto 15px;padding:5mm;background:#fff;border:1px solid #777}
.inv-head{position:relative;min-height:27px;margin-bottom:3px;padding:0 76px 2px 4px;border-bottom:2px solid #263238}
.inv-head h1{margin:0;text-align:center;font-size:15px;line-height:23px;font-weight:800;white-space:nowrap}
.inv-no{position:absolute;right:3px;top:2px;color:#c62828;font-size:11.5px;font-weight:800;white-space:nowrap}
.invoice table{width:100%;border-collapse:collapse}
.info{margin-top:3px;table-layout:fixed}.info td{border:1px solid #5f6b75;padding:3px 4px;text-align:center;font-size:11px;line-height:13px;font-weight:600}.info .label{width:12%;background:#eef2f5;font-weight:800}.info .value{width:38%;font-weight:700;word-break:break-word}
.details{margin-top:3px;table-layout:fixed}.details th{background:#1976d2;color:white;border:1px solid #455a64;padding:3px;font-size:10px;line-height:11px;font-weight:800}.details td{border:1px solid #54616b;padding:3px;font-size:10px;line-height:11px;font-weight:700;text-align:center;white-space:nowrap}
.details th:nth-child(1),.details td:nth-child(1){width:15%}.details th:nth-child(2),.details td:nth-child(2){width:14%}.details th:nth-child(3),.details td:nth-child(3){width:11%}.details th:nth-child(4),.details td:nth-child(4){width:11%}.details th:nth-child(5),.details td:nth-child(5){width:12%}.details th:nth-child(6),.details td:nth-child(6){width:17%}.details th:nth-child(7),.details td:nth-child(7){width:20%}
.totals-row{display:flex;gap:3px;width:100%;margin-top:3px}.total-box{flex:1;min-width:0;display:flex;align-items:center;justify-content:center;flex-direction:column;text-align:center;padding:4px 5px;border:1px solid #4b5560;background:#f5f7f9;font-size:9.5px;font-weight:800;line-height:12px}.total-title{font-weight:800;white-space:nowrap}.total-value{font-weight:900;white-space:nowrap;margin-right:0;margin-top:2px}.arrears-box{color:#c62828}.grand-box{background:#e8eef5;border-width:2px;font-size:11px}
.words{margin-top:3px;padding:4px 5px;border:1px solid #5b6772;background:#fafbfc;font-size:9.5px;line-height:12px;font-weight:800;white-space:normal;overflow:visible}
.subscriber-print-summary{width:100%;max-width:198mm;margin:0 auto 4mm;padding:3mm;background:#fff;border:1px solid #54616b}.summary-title{text-align:center;font-weight:900;font-size:13px;margin-bottom:2mm;color:#17324d}.subscriber-print-summary table{width:100%;border-collapse:collapse;table-layout:fixed}.subscriber-print-summary td{border:1px solid #7b8791;padding:2.5px 4px;text-align:center;font-size:10px;line-height:12px;font-weight:700}.subscriber-print-summary .label{background:#eef2f5;font-weight:900;width:14%}.subscriber-print-summary .value{width:36%}.subscriber-print-summary .arrears{color:#c62828;font-weight:900}.actions{text-align:center;margin:15px}.actions button,.actions a{display:inline-block;padding:10px 16px;margin:4px}
.compact{width:100%;height:91mm;min-height:91mm;max-height:91mm;overflow:hidden;padding:2.5mm 3mm;margin:0 0 1.5mm 0;border:1px solid #777;page-break-inside:avoid;break-inside:avoid;display:flex;flex-direction:column;box-sizing:border-box}
.compact .inv-head{min-height:23px;margin-bottom:2px;padding-right:64px}.compact .inv-head h1{font-size:11px;line-height:18px}.compact .inv-no{right:2px;top:2px;font-size:9px}
.compact .info{margin-top:2px}.compact .info td{font-size:7.8px;padding:2px;line-height:8.5px}.compact .details{margin-top:2px}.compact .details th{font-size:7.4px;padding:2px;line-height:8px}.compact .details td{font-size:7.5px;padding:2px;line-height:8px}
.compact .totals-row{gap:2px;margin-top:2px}.compact .total-box{padding:2px 3px;font-size:7px;line-height:8px}.compact .grand-box{font-size:7.8px;border-width:1px}.compact .words{margin-top:2px;padding:2px 3px;font-size:7.2px;line-height:8.5px;white-space:normal;overflow:visible}
@page{size:A4 portrait;margin:4mm}
.bulk-wrap .compact .inv-head{flex:0 0 auto}.bulk-wrap .compact .info{flex:0 0 auto}.bulk-wrap .compact .details{flex:1 1 auto}.bulk-wrap .compact .totals-row{flex:0 0 auto}.bulk-wrap .compact .words{flex:0 0 auto}\n@media print{`r`n html,body{width:100%;margin:0;padding:0;background:#fff!important}`r`n .invoice{width:100%;max-width:198mm;margin:0 auto;padding:4mm;border:1px solid #555;box-shadow:none}`r`n .bulk-wrap{display:block;width:100%;margin:0;padding:0}`r`n .bulk-wrap .compact{display:block;width:100%;max-width:198mm;height:91mm;min-height:91mm;max-height:91mm;margin:0;padding:3.2mm;overflow:hidden;page-break-inside:avoid;break-inside:avoid}`r`n .bulk-wrap .compact:nth-child(3n){page-break-after:always;break-after:page}`r`n .actions{display:none!important}`r`n}`r`n@media(max-width:700px){
 .invoice{max-width:none;padding:10px;margin:0 0 10px}
 .inv-head{padding-right:70px}
 .inv-head h1{font-size:13px;line-height:20px}
 .inv-no{font-size:10px}
 .info td{font-size:10px;padding:3px}
 .details{min-width:650px}
 .details th,.details td{font-size:9px;padding:3px}
 .totals-row{flex-direction:column;gap:3px}
 .total-box{font-size:10px}
 .words{font-size:9px;white-space:normal}
}
</style>
"""



def subscriber_summary_card(cur, invoice_id):
    r=cur.execute("""
        SELECT i.id AS invoice_id,s.id AS subscriber_id,s.name,s.phone,s.address,
               COALESCE(s.previous_arrears,0) AS subscriber_arrears,
               (SELECT COUNT(*) FROM meters m WHERE m.subscriber_id=s.id) AS meter_count
        FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id
        WHERE i.id=?
    """,(invoice_id,)).fetchone()
    if not r:return ""
    return f"""
    <section class="subscriber-print-summary">
      <div class="summary-title">بيانات المشترك</div>
      <table>
        <tr><td class="label">رقم المشترك</td><td class="value">{r['subscriber_id']}</td><td class="label">اسم المشترك</td><td class="value">{esc(r['name'])}</td></tr>
        <tr><td class="label">الهاتف</td><td class="value">{esc(r['phone'])}</td><td class="label">العنوان</td><td class="value">{esc(r['address'])}</td></tr>
        <tr><td class="label">عدد العدادات</td><td class="value">{r['meter_count']}</td><td class="label">المتأخرات المسجلة</td><td class="value arrears">{money(r['subscriber_arrears'])}</td></tr>
      </table>
    </section>
    """


def invoice_card(cur, invoice_id, compact=False, request=None):
    r=cur.execute("""
        SELECT i.id,i.invoice_date,s.name,s.phone,s.address,
               i.consumption_total,i.previous_arrears,i.total_due,
               i.amount_words,i.closed
        FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id
        WHERE i.id=?
    """,(invoice_id,)).fetchone()
    if not r:return ""

    ds=cur.execute("""
        SELECT meter_type,actual_meter_number,previous_reading,current_reading,
               consumption,unit_price,consumption_value
        FROM invoice_details WHERE invoice_id=? ORDER BY id
    """,(invoice_id,)).fetchall()

    details="".join(f"""<tr><td>{esc(d['meter_type'])}</td><td>{esc(d['actual_meter_number'])}</td><td><b>{d['previous_reading']}</b></td><td><b>{d['current_reading']}</b></td><td><b>{d['consumption']}</b></td><td>{money(d['unit_price'])}</td><td><b>{money(d['consumption_value'])}</b></td></tr>""" for d in ds)
    if not details:
        details='<tr><td colspan="7" style="color:#888">لا توجد قراءات مسجلة لهذه الفاتورة.</td></tr>'

    cls="invoice compact" if compact else "invoice"
    return f"""
    <section class="{cls}">
        <div class="inv-head"><div class="inv-no">رقم الفاتورة {r['id']}</div><h1>فاتورة المياه والكهرباء - مشروع الغميس</h1></div>
        <table class="info">
            <tr><td class="label">المشترك</td><td class="value">{esc(r['name'])}</td><td class="label">التاريخ</td><td class="value">{r['invoice_date']}</td></tr>
            <tr><td class="label">الهاتف</td><td class="value">{esc(r['phone'])}</td><td class="label">العنوان</td><td class="value">{esc(r['address'])}</td></tr>
        </table>
        <table class="details">
            <tr><th>نوع العداد</th><th>رقم العداد</th><th>السابقة</th><th>الحالية</th><th>الاستهلاك</th><th>سعر الوحدة</th><th>القيمة</th></tr>
            {details}
        </table>
        <div class="totals-row">
            <div class="total-box"><span class="total-title">إجمالي الاستهلاك</span><span class="total-value">{money(r['consumption_total'])}</span></div>
            <div class="total-box arrears-box"><span class="total-title">المتأخرات السابقة</span><span class="total-value">{money(r['previous_arrears'])}</span></div>
            <div class="total-box grand-box"><span class="total-title">المبلغ المطلوب</span><span class="total-value">{money(r['total_due'])}</span></div>
        </div>
        <div class="words">المبلغ كتابةً: {esc(r['amount_words'] or number_to_arabic_words(r['total_due']))}</div>
    </section>
    """


# =========================================================
# الفواتير
# =========================================================

@app.get("/invoices", response_class=HTMLResponse)
def invoices_page(request: Request):
    c=get_connection(); x=c.cursor()
    inv=x.execute("""
        SELECT i.id,i.invoice_date,s.name,i.total_due,i.previous_arrears,i.closed,i.subscriber_id,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.invoice_id=i.id),0) paid
        FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id ORDER BY i.id DESC
    """).fetchall()
    subs=x.execute("SELECT id,name FROM subscribers ORDER BY name").fetchall(); c.close()
    rows="".join(f"""<tr>
    <td class="red">{i['id']}</td><td>{i['invoice_date']}</td><td>{esc(i['name'])}</td><td>{money(i['total_due'])}</td><td class="red">{money(i['previous_arrears'])}</td>
    <td>{money(i['paid'])}</td><td>{money(max(0,float(i['total_due'] or 0)-float(i['paid'] or 0)))}</td><td>{'مغلقة' if i['closed'] else 'مفتوحة'}</td>
    <td><a class="btn" href="/invoice/{i['id']}">عرض</a><a class="btn gray" href="/print-invoice/{i['id']}">طباعة</a><a class="btn green" href="/new-payment/{i['id']}">سداد</a>
    <a class="btn purple" href="/whatsapp/invoice/{i['id']}">واتساب</a>
    {f'<a class="btn gray" href="/reopen-invoice/{i["id"]}">إعادة فتح</a>' if i['closed'] else f'<a class="btn orange" href="/print-and-close/{i["id"]}" onclick="return confirm(\'بعد الترحيل سيتم إغلاق الفاتورة. متابعة؟\')">طباعة وترحيل</a>'}
    </td></tr>""" for i in inv)
    opts="".join(f'<option value="{s["id"]}">{esc(s["name"])}</option>' for s in subs)
    body=f"""
    <div class="card"><h2>🧾 الفواتير</h2>
      <form action="/create-invoice" method="get"><div class="grid"><div class="field"><label>اختيار المشترك لعرض فاتورته المفتوحة</label><select name="subscriber_id" required><option value="">اختر المشترك</option>{opts}</select></div></div><br><button>فتح الفاتورة</button></form>
      <p class="muted">لن يتم إنشاء فاتورة من هذه الصفحة إذا لم توجد قراءة مرتبطة بها؛ إنشاء الفاتورة يبدأ مع أول قراءة جديدة.</p>
    </div>
    <div class="card"><div class="actions"><a class="btn" href="/print-all">🖨️ طباعة جماعية (3 فواتير لكل ورقة A4)</a><a class="btn purple" href="/whatsapp/invoices">📱 فواتير واتساب</a><a class="btn arrears" href="/report-arrears">⚠️ المتأخرات</a></div></div>
    <div class="card table-wrap"><table><tr><th>رقم</th><th>التاريخ</th><th>المشترك</th><th>المطلوب</th><th>المتأخرات</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th><th>الإجراء</th></tr>{rows}</table></div>
    """
    return page(request,"الفواتير",body)


@app.get("/create-invoice", response_class=HTMLResponse)
def create_invoice_from_select(request: Request, subscriber_id:int):
    return create_invoice(request,subscriber_id)


@app.get("/create-invoice/{subscriber_id}")
def create_invoice(request: Request, subscriber_id:int):
    c=get_connection(); x=c.cursor()
    s=x.execute("SELECT name FROM subscribers WHERE id=?",(subscriber_id,)).fetchone()
    if not s:
        c.close(); set_flash(request,"المشترك غير موجود.","error"); return RedirectResponse("/invoices",303)
    iid=get_open_invoice_id(x,subscriber_id)
    if iid is None:
        row=x.execute("SELECT id FROM readings WHERE invoice_id IS NULL AND meter_id IN (SELECT id FROM meters WHERE subscriber_id=?) ORDER BY reading_date,id LIMIT 1",(subscriber_id,)).fetchone()
        if row:
            # إصلاح توافق للقراءات القديمة غير المرتبطة بالفواتير.
            first=x.execute("SELECT m.subscriber_id,r.reading_date FROM readings r JOIN meters m ON r.meter_id=m.id WHERE r.id=?",(row['id'],)).fetchone()
            iid=new_invoice_for_reading(x,subscriber_id,first['reading_date'])
            x.execute("UPDATE readings SET invoice_id=? WHERE invoice_id IS NULL AND meter_id IN (SELECT id FROM meters WHERE subscriber_id=?)",(iid,subscriber_id))
            build_invoice(x,subscriber_id,iid)
            c.commit()
        else:
            c.close(); set_flash(request,"لا توجد قراءة غير مفوترة لهذا المشترك؛ أدخل قراءة أولًا لإنشاء الفاتورة.","warning"); return RedirectResponse("/readings",303)
    else:
        build_invoice(x,subscriber_id,iid); c.commit()
    c.close(); return RedirectResponse(f"/invoice/{iid}",303)


@app.get("/invoice/{invoice_id}", response_class=HTMLResponse)
def show_invoice(request: Request,invoice_id:int):
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT closed FROM invoices WHERE id=?",(invoice_id,)).fetchone()
    if not r:c.close(); return HTMLResponse("<h2>الفاتورة غير موجودة</h2>")
    content=invoice_card(x,invoice_id,request=request); closed=bool(r['closed']); paid=invoice_paid(x,invoice_id); balance=invoice_balance(x,invoice_id)
    info=x.execute("SELECT i.id,i.total_due,s.name,s.phone FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id WHERE i.id=?",(invoice_id,)).fetchone()
    c.close()
    pdf_public_url=public_invoice_url(request,invoice_id,True)
    wa_message=f"السلام عليكم {info['name']}\nفاتورتكم من مشروع الغميس رقم {info['id']} بقيمة {money(info['total_due'])}.\nرابط الفاتورة PDF: {pdf_public_url}" if info else ""
    wa_pdf_url=whatsapp_url(info['phone'],wa_message) if info else ""
    wa_pdf_btn=f'<a class="btn purple" target="_blank" href="{esc(wa_pdf_url)}">📱 إرسال PDF واتساب</a>' if wa_pdf_url else ''
    actions=f'<button onclick="location.href=&apos;/print-invoice/{invoice_id}&apos;">🖨️ طباعة</button><a class="btn gray" href="/pdf-invoice/{invoice_id}">📄 PDF حفظ</a><button class="btn share" type="button" onclick="sharePdf(&quot;/pdf-invoice/{invoice_id}&quot;,&quot;فاتورة-{invoice_id}.pdf&quot;)">📤 مشاركة PDF</button>{wa_pdf_btn}<a class="btn green" href="/new-payment/{invoice_id}">💳 سداد ({money(balance)})</a><a class="btn purple" href="/whatsapp/invoice/{invoice_id}">📱 واتساب</a>'
    actions += f'<a class="btn orange" href="/reopen-invoice/{invoice_id}">إعادة فتح</a>' if closed else f'<a class="btn orange" href="/print-and-close/{invoice_id}" onclick="return confirm(\'بعد الترحيل لن تدخل القراءات التالية لهذه الفاتورة. متابعة؟\')">طباعة وترحيل</a>'
    body=f"""{content}<div class="card"><div class="actions">{actions}<a class="btn gray" href="/invoices">الفواتير</a></div><p class="muted">المدفوع على الفاتورة: {money(paid)} — المتبقي: <b>{money(balance)}</b></p></div>"""
    return page(request,f"فاتورة رقم {invoice_id}",body)


@app.get("/print-invoice/{invoice_id}", response_class=HTMLResponse)
def print_invoice(request: Request, invoice_id: int):
    c = get_connection()
    x = c.cursor()
    row = x.execute("""
        SELECT i.id, s.name, s.phone
        FROM invoices i
        JOIN subscribers s ON i.subscriber_id=s.id
        WHERE i.id=?
    """, (invoice_id,)).fetchone()
    if not row:
        c.close()
        return HTMLResponse("<h2>الفاتورة غير موجودة</h2>", status_code=404)

    subscriber_name = str(row["name"] or f"فاتورة-{invoice_id}")
    summary = subscriber_summary_card(x, invoice_id)
    content = invoice_card(x, invoice_id, request=request)
    pdf_public_url = public_invoice_url(request, invoice_id, True)
    wa_message = f"السلام عليكم {subscriber_name}\nفاتورتكم من مشروع الغميس رقم {invoice_id}.\nرابط الفاتورة PDF: {pdf_public_url}"
    wa_pdf_url = whatsapp_url(row["phone"], wa_message) if row["phone"] else ""
    wa_pdf_button = f'<a class="btn purple" target="_blank" href="{esc(wa_pdf_url)}">📱 إرسال PDF واتساب</a>' if wa_pdf_url else ''
    c.close()

    share_name = "".join(ch for ch in subscriber_name if ch not in '<>:"/\\|?*').strip() or f"فاتورة-{invoice_id}"
    filename = f"{share_name}.pdf"

    return f"""<!doctype html><html lang='ar' dir='rtl'>
<head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>طباعة - {esc(subscriber_name)}</title>{INVOICE_CSS}</head>
<body>{content}
<div class='actions'>
<button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة</button>
<a class='btn gray' href='/pdf-invoice/{invoice_id}'>📄 PDF حفظ</a>
<button class='btn share' onclick='sharePdf(&quot;/pdf-invoice/{invoice_id}&quot;,&quot;{esc(filename)}&quot;)'>📤 مشاركة PDF</button>{wa_pdf_button}
<a class='btn gray' href='/invoices'>عودة</a>
</div></body></html>"""


@app.get("/pdf-invoice/{invoice_id}")
def pdf_invoice(request: Request, invoice_id: int):
    if WeasyHTML is None:
        return RedirectResponse(f"/print-invoice/{invoice_id}", 303)

    c = get_connection()
    x = c.cursor()
    row = x.execute("""
        SELECT i.id, s.name
        FROM invoices i
        JOIN subscribers s ON i.subscriber_id=s.id
        WHERE i.id=?
    """, (invoice_id,)).fetchone()

    if not row:
        c.close()
        return HTMLResponse("الفاتورة غير موجودة", status_code=404)

    subscriber_name = str(row["name"] or f"فاتورة-{invoice_id}")
    summary = subscriber_summary_card(x, invoice_id)
    content = invoice_card(x, invoice_id, request=request)
    c.close()

    html = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>{esc(subscriber_name)}</title>
{INVOICE_CSS}
</head>
<body>{content}</body>
</html>"""

    try:
        pdf = WeasyHTML(string=html, base_url=str(BASE_DIR)).write_pdf()
    except Exception as e:
        return HTMLResponse(
            f"<h2>حدث خطأ أثناء إنشاء PDF</h2><pre>{esc(e)}</pre>",
            status_code=500
        )

    safe_name = "".join(ch for ch in subscriber_name if ch not in '<>:"/\\|?*').strip()
    if not safe_name:
        safe_name = f"فاتورة-{invoice_id}"

    filename = f"{safe_name}.pdf"
    encoded_filename = quote(filename)

    return Response(
        pdf,
        media_type="application/pdf",
        headers={
            "Content-Disposition":
                f'attachment; filename="invoice_{invoice_id}.pdf"; '
                f"filename*=UTF-8''{encoded_filename}"
        }
    )


@app.get("/print-all", response_class=HTMLResponse)
def print_all(request: Request):
    c=get_connection(); x=c.cursor()
    ids=[r['id'] for r in x.execute("SELECT id FROM invoices WHERE closed=0 AND EXISTS(SELECT 1 FROM readings WHERE readings.invoice_id=invoices.id) ORDER BY subscriber_id,id").fetchall()]
    cards="".join(invoice_card(x,i,True,request=request) for i in ids); c.close()
    cards=f"<div class='bulk-wrap'>{cards}</div>"
    if not ids:
        return page(request,"المعاينة الجماعية",'<div class="card"><h2>لا توجد فواتير مفتوحة تحتوي على قراءات.</h2><a class="btn" href="/readings">إدخال القراءات</a></div>')
    html=f"""<div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة جماعية (3 فواتير لكل ورقة A4)</button><a class='btn gray' href='/pdf-print-all'>📄 PDF للجميع</a><button class='btn share' onclick='sharePdf(&quot;/pdf-print-all&quot;,&quot;فواتير-المشتركين.pdf&quot;)'>📤 مشاركة PDF</button><a class='btn gray' href='/invoices'>عودة</a></div>{cards}"""
    return f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>{INVOICE_CSS}</head><body>{html}</body></html>"


@app.get("/pdf-print-all")
def pdf_print_all(request: Request):
    if WeasyHTML is None:
        return RedirectResponse("/print-all",303)
    c=get_connection(); x=c.cursor()
    ids=[r["id"] for r in x.execute("SELECT id FROM invoices WHERE closed=0 AND EXISTS(SELECT 1 FROM readings WHERE readings.invoice_id=invoices.id) ORDER BY subscriber_id,id").fetchall()]
    cards="".join(invoice_card(x,i,True,request=request) for i in ids); c.close()
    cards=f"<div class='bulk-wrap'>{cards}</div>"
    if not ids:return HTMLResponse("لا توجد فواتير للطباعة.",status_code=404)
    html=f"<html lang='ar' dir='rtl'><head><meta charset='UTF-8'>{INVOICE_CSS}</head><body>{cards}</body></html>"
    pdf=WeasyHTML(string=html,base_url=str(BASE_DIR)).write_pdf()
    return Response(pdf,media_type="application/pdf",headers={"Content-Disposition":"attachment; filename=invoices-all.pdf"})


@app.get("/print-and-close/{invoice_id}", response_class=HTMLResponse)
def print_and_close(request: Request,invoice_id:int):
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT closed,subscriber_id FROM invoices WHERE id=?",(invoice_id,)).fetchone()
    if not r:c.close(); return HTMLResponse("<h2>الفاتورة غير موجودة</h2>")
    if not r['closed']:
        x.execute("UPDATE invoices SET closed=1 WHERE id=?",(invoice_id,))
        c.commit()
    content=invoice_card(x,invoice_id,request=request); c.close()
    return f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><title>طباعة وترحيل</title>{INVOICE_CSS}</head><body>{content}<div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة الفاتورة</button><a class='btn gray' href='/invoices'>الفواتير</a></div><script>window.onload=function(){{setTimeout(function(){{location.href=&apos;/print-invoice/{invoice_id}&apos;}},300)}};</script></body></html>"


@app.get("/reopen-invoice/{invoice_id}")
def reopen_invoice(request: Request,invoice_id:int):
    c=get_connection(); x=c.cursor(); r=x.execute("SELECT subscriber_id FROM invoices WHERE id=?",(invoice_id,)).fetchone()
    if r:
        x.execute("UPDATE invoices SET closed=0 WHERE id=?",(invoice_id,)); build_invoice(x,r['subscriber_id'],invoice_id); c.commit()
    c.close(); set_flash(request,"تم إعادة فتح الفاتورة.","warning")
    return RedirectResponse(f"/invoice/{invoice_id}",303)


# =========================================================
# المدفوعات / السداد
# =========================================================

@app.get("/payments", response_class=HTMLResponse)
def payments_page(request: Request):
    c=get_connection(); x=c.cursor()
    rows=x.execute("""
        SELECT p.id,p.payment_date,p.amount,p.notes,i.id invoice_id,s.name,i.total_due,
        COALESCE((SELECT SUM(p2.amount) FROM payments p2 WHERE p2.invoice_id=i.id),0) paid
        FROM payments p JOIN invoices i ON p.invoice_id=i.id JOIN subscribers s ON p.subscriber_id=s.id ORDER BY p.id DESC
    """).fetchall()
    subs=x.execute("SELECT id,name FROM subscribers ORDER BY name").fetchall(); c.close()
    opts="".join(f'<option value="{s["id"]}">{esc(s["name"])}</option>' for s in subs)
    table="".join(f"""<tr><td>{p['id']}</td><td>{p['payment_date']}</td><td>{esc(p['name'])}</td><td>{p['invoice_id']}</td><td>{money(p['amount'])}</td><td>{money(max(0,float(p['total_due'] or 0)-float(p['paid'] or 0)))}</td><td>{esc(p['notes'])}</td><td><a class="btn orange" href="/edit-payment/{p['id']}">تعديل</a><a class="btn red" href="/delete-payment/{p['id']}" onclick="return confirm('حذف السداد؟')">حذف</a></td></tr>""" for p in rows)
    body=f"""
    <div class="card"><h2>💳 المدفوعات والسداد</h2><form method="get" action="/subscriber-invoices"><div class="grid"><div class="field"><label>المشترك</label><select name="subscriber_id" required><option value="">اختر المشترك</option>{opts}</select></div></div><br><button>عرض فواتير المشترك</button></form></div>
    <div class="card table-wrap"><table><tr><th>رقم السداد</th><th>التاريخ</th><th>المشترك</th><th>الفاتورة</th><th>المبلغ</th><th>متبقي الفاتورة</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div>
    """
    return page(request,"المدفوعات",body)


@app.get("/subscriber-invoices", response_class=HTMLResponse)
def subscriber_invoices(request: Request,subscriber_id:int):
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone()
    if not s:c.close(); return HTMLResponse("<h2>المشترك غير موجود</h2>")
    inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id DESC",(subscriber_id,)).fetchall(); c.close()
    rows="".join(f"""<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x if False else get_connection().cursor(),i['id']))}</td></tr>""" for i in [])
    # إعادة الحساب في اتصال واحد.
    c=get_connection(); x=c.cursor(); rows="".join(f"""<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td><td>{'مغلقة' if i['closed'] else 'مفتوحة'}</td><td><a class="btn green" href="/new-payment/{i['id']}">سداد</a><a class="btn" href="/invoice/{i['id']}">الفاتورة</a></td></tr>""" for i in inv); c.close()
    body=f"""<div class="card"><h2>فواتير المشترك: {esc(s['name'])}</h2><div class="table-wrap"><table><tr><th>الفاتورة</th><th>التاريخ</th><th>المطلوب</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th><th>الإجراء</th></tr>{rows}</table></div><br><a class="btn gray" href="/payments">عودة</a></div>"""
    return page(request,"فواتير المشترك",body)


@app.get("/new-payment/{invoice_id}", response_class=HTMLResponse)
def new_payment(request: Request,invoice_id:int):
    c=get_connection(); x=c.cursor(); inv=x.execute("""
        SELECT i.*,s.name FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id WHERE i.id=?
    """,(invoice_id,)).fetchone()
    if not inv:c.close(); return HTMLResponse("<h2>الفاتورة غير موجودة</h2>")
    balance=invoice_balance(x,invoice_id); c.close()
    body=f"""<div class="card" style="max-width:700px;margin:auto"><h2>💳 تسجيل سداد</h2><p>المشترك: <b>{esc(inv['name'])}</b> — الفاتورة: <b>{invoice_id}</b> — المطلوب: <b>{money(inv['total_due'])}</b> — المتبقي: <b class='red'>{money(balance)}</b></p>
    <form method="post" action="/save-payment"><input type="hidden" name="invoice_id" value="{invoice_id}"><div class="grid"><input name="payment_date" type="date" value="{date.today().isoformat()}" required><input name="amount" type="number" step=".01" min=".01" max="{balance}" required placeholder="مبلغ السداد"><input name="notes" placeholder="ملاحظات"></div><br><button>💾 حفظ السداد</button> <a class="btn gray" href="/payments">عودة</a></form></div>"""
    return page(request,"تسجيل سداد",body)


@app.post("/save-payment")
def save_payment(request: Request,invoice_id:int=Form(...),payment_date:str=Form(...),amount:float=Form(...),notes:str=Form("")):
    c=get_connection(); x=c.cursor(); inv=x.execute("SELECT subscriber_id,total_due FROM invoices WHERE id=?",(invoice_id,)).fetchone()
    if not inv:
        c.close(); set_flash(request,"الفاتورة غير موجودة.","error"); return RedirectResponse("/payments",303)
    balance=invoice_balance(x,invoice_id)
    if amount <= 0 or amount > balance + 1e-9:
        c.close(); set_flash(request,f"المبلغ أكبر من المتبقي. المتاح: {money(balance)}","error"); return RedirectResponse(f"/new-payment/{invoice_id}",303)
    x.execute("INSERT INTO payments(invoice_id,subscriber_id,payment_date,amount,notes) VALUES(?,?,?,?,?)",(invoice_id,inv['subscriber_id'],payment_date,amount,notes))
    refresh_open_invoice_for_subscriber(x,inv['subscriber_id'])
    c.commit(); c.close(); set_flash(request,"تم تسجيل السداد وتحديث الرصيد.")
    return RedirectResponse("/payments",303)


@app.get("/edit-payment/{payment_id}", response_class=HTMLResponse)
def edit_payment(request: Request,payment_id:int):
    c=get_connection(); x=c.cursor(); p=x.execute("SELECT p.*,s.name,i.total_due FROM payments p JOIN subscribers s ON p.subscriber_id=s.id JOIN invoices i ON p.invoice_id=i.id WHERE p.id=?",(payment_id,)).fetchone()
    if not p:c.close(); return HTMLResponse("<h2>السداد غير موجود</h2>")
    allowed=invoice_balance(x,p['invoice_id'],payment_id); c.close()
    body=f"""<div class="card" style="max-width:700px;margin:auto"><h2>تعديل السداد</h2><p>المشترك: <b>{esc(p['name'])}</b> — الفاتورة: <b>{p['invoice_id']}</b> — المتاح لتعديل هذا السداد: <b>{money(allowed)}</b></p>
    <form method="post" action="/update-payment/{p['id']}"><div class="grid"><input name="payment_date" type="date" value="{p['payment_date']}" required><input name="amount" type="number" step=".01" min=".01" max="{allowed}" value="{p['amount']}" required><input name="notes" value="{esc(p['notes'])}"></div><br><button>حفظ التعديل</button> <a class="btn gray" href="/payments">عودة</a></form></div>"""
    return page(request,"تعديل السداد",body)


@app.post("/update-payment/{payment_id}")
def update_payment(request: Request,payment_id:int,payment_date:str=Form(...),amount:float=Form(...),notes:str=Form("")):
    c=get_connection(); x=c.cursor(); p=x.execute("SELECT invoice_id,subscriber_id FROM payments WHERE id=?",(payment_id,)).fetchone()
    if not p:
        c.close(); set_flash(request,"السداد غير موجود.","error"); return RedirectResponse("/payments",303)
    allowed=invoice_balance(x,p['invoice_id'],payment_id)
    if amount <= 0 or amount > allowed + 1e-9:
        c.close(); set_flash(request,f"المبلغ أكبر من المتاح للتعديل: {money(allowed)}","error"); return RedirectResponse(f"/edit-payment/{payment_id}",303)
    x.execute("UPDATE payments SET payment_date=?,amount=?,notes=? WHERE id=?",(payment_date,amount,notes,payment_id))
    refresh_open_invoice_for_subscriber(x,p['subscriber_id']); c.commit(); c.close(); set_flash(request,"تم تعديل السداد.")
    return RedirectResponse("/payments",303)


@app.get("/delete-payment/{payment_id}")
def delete_payment(request: Request,payment_id:int):
    c=get_connection(); x=c.cursor(); p=x.execute("SELECT subscriber_id FROM payments WHERE id=?",(payment_id,)).fetchone()
    if p:
        x.execute("DELETE FROM payments WHERE id=?",(payment_id,)); refresh_open_invoice_for_subscriber(x,p['subscriber_id']); c.commit()
    c.close(); set_flash(request,"تم حذف السداد.","warning"); return RedirectResponse("/payments",303)


# =========================================================
# حسابات المشتركين
# =========================================================

@app.get("/accounts", response_class=HTMLResponse)
def accounts_page(request: Request):
    c=get_connection(); subs=c.execute("SELECT id,name FROM subscribers ORDER BY name").fetchall(); c.close()
    opts="".join(f'<option value="{s["id"]}">{esc(s["name"])}</option>' for s in subs)
    body=f"""<div class="card"><h2>📊 حسابات المشتركين</h2><form method="get" action="/account"><div class="grid"><select name="subscriber_id" required><option value="">اختر المشترك</option>{opts}</select></div><br><div class="actions"><button>عرض كشف الحساب</button><a class="btn gray" href="/print-accounts">🖨️ طباعة كشوف المشتركين</a><a class="btn gray" href="/pdf-accounts">📄 PDF للمشتركين</a><button class="btn share" type="button" onclick='sharePdf(&quot;/pdf-accounts&quot;,&quot;كشوف-المشتركين.pdf&quot;)'>📤 مشاركة PDF</button></div></form></div>"""
    return page(request,"حسابات المشتركين",body)


@app.get("/account", response_class=HTMLResponse)
def account_select(request: Request,subscriber_id:int):
    return account_page(request,subscriber_id)


@app.get("/account/{subscriber_id}", response_class=HTMLResponse)
def account_page(request: Request,subscriber_id:int):
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone()
    if not s:c.close(); return HTMLResponse("<h2>المشترك غير موجود</h2>")
    inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id",(subscriber_id,)).fetchall()
    total_consumption=sum(float(i['consumption_total'] or 0) for i in inv)
    total_due=sum(float(i['total_due'] or 0) for i in inv)
    total_paid=sum(float(r[0] or 0) for r in [x.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE invoice_id=?",(i['id'],)).fetchone() for i in inv])
    current_balance=account_balance(x,subscriber_id)
    rows="".join(f"""<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['consumption_total'])}</td><td>{money(i['previous_arrears'])}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td><td>{'مغلقة' if i['closed'] else 'مفتوحة'}</td><td><a class="btn" href="/invoice/{i['id']}">الفاتورة</a><a class="btn green" href="/new-payment/{i['id']}">سداد</a></td></tr>""" for i in inv)
    c.close()
    body=f"""<div class="card"><h2>كشف حساب المشترك: {esc(s['name'])}</h2><p>الهاتف: {esc(s['phone'])} | العنوان: {esc(s['address'])}</p>
    <div class="stats"><div class="stat"><b>{money(total_consumption)}</b><span>إجمالي الاستهلاك</span></div><div class="stat"><b>{money(total_paid)}</b><span>إجمالي المدفوع</span></div><div class="stat"><b>{money(current_balance)}</b><span>الرصيد المتبقي الحقيقي</span></div></div><br>
    <div class="actions"><a class="btn" href="/print-account/{subscriber_id}">🖨️ طباعة كشف الحساب</a><a class="btn gray" href="/pdf-account/{subscriber_id}">📄 PDF حفظ</a><button class="btn share" type="button" onclick="sharePdf(&quot;/pdf-account/{subscriber_id}&quot;,&quot;كشف-{subscriber_id}.pdf&quot;)">📤 مشاركة PDF</button><a class="btn purple" href="/whatsapp/arrears/{subscriber_id}">📱 تنبيه واتساب</a></div></div>
    <div class="card table-wrap"><table><tr><th>الفاتورة</th><th>التاريخ</th><th>الاستهلاك</th><th>متأخرات سابقة</th><th>المطلوب</th><th>المدفوع</th><th>متبقي الفاتورة</th><th>الحالة</th><th>الإجراء</th></tr>{rows}</table></div>"""
    return page(request,"كشف حساب",body)


@app.get("/print-account/{subscriber_id}", response_class=HTMLResponse)
def print_account(request: Request,subscriber_id:int):
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone(); inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id",(subscriber_id,)).fetchall()
    if not s:c.close(); return HTMLResponse("<h2>المشترك غير موجود</h2>")
    total=account_balance(x,subscriber_id)
    rows="".join(f"<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['consumption_total'])}</td><td>{money(i['previous_arrears'])}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td><td>{'مغلقة' if i['closed'] else 'مفتوحة'}</td></tr>" for i in inv)
    c.close()
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><title>كشف حساب</title><style>body{{font-family:Arial;direction:rtl;margin:20px}}h1{{text-align:center}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:7px;text-align:center}}th{{background:#eee}}.sum{{margin:12px 0;font-size:18px;font-weight:bold}}@media print{{button{{display:none}}}}</style></head><body><h1>كشف حساب المشترك</h1><h3>{esc(s['name'])}</h3><p>الهاتف: {esc(s['phone'])} | العنوان: {esc(s['address'])}</p><div class='sum'>الرصيد المتبقي الحالي: {money(total)}</div><table><tr><th>الفاتورة</th><th>التاريخ</th><th>الاستهلاك</th><th>متأخرات البداية</th><th>المطلوب</th><th>المدفوع</th><th>متبقي الفاتورة</th><th>الحالة</th></tr>{rows}</table><br><div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة</button><a class='btn' href='/pdf-account/{subscriber_id}'>📄 PDF حفظ</a><button class='btn share' onclick="sharePdf(&quot;/pdf-account/{subscriber_id}&quot;,&quot;كشف-{subscriber_id}.pdf&quot;)">📤 مشاركة PDF</button></div></body></html>"""


@app.get("/pdf-account/{subscriber_id}")
def pdf_account(request: Request,subscriber_id:int):
    if WeasyHTML is None:return RedirectResponse(f"/print-account/{subscriber_id}",303)
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone(); inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id",(subscriber_id,)).fetchall()
    if not s:c.close();return HTMLResponse("المشترك غير موجود",status_code=404)
    total=account_balance(x,subscriber_id)
    rows="".join(f"<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['consumption_total'])}</td><td>{money(i['previous_arrears'])}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td><td>{'مغلقة' if i['closed'] else 'مفتوحة'}</td></tr>" for i in inv)
    c.close(); html=f"<html lang='ar' dir='rtl'><head><meta charset='UTF-8'><style>body{{font-family:Arial;direction:rtl;margin:20px}}h1{{text-align:center}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:7px;text-align:center}}th{{background:#e8eef5}}</style></head><body><h1>كشف حساب المشترك</h1><h3>{esc(s['name'])}</h3><p>الهاتف: {esc(s['phone'])} | العنوان: {esc(s['address'])}</p><h3>الرصيد المتبقي الحالي: {money(total)}</h3><table><tr><th>الفاتورة</th><th>التاريخ</th><th>الاستهلاك</th><th>متأخرات سابقة</th><th>المطلوب</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th></tr>{rows}</table></body></html>"; pdf=WeasyHTML(string=html,base_url=str(BASE_DIR)).write_pdf(); return Response(pdf,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="account-{subscriber_id}.pdf"'})

@app.get("/print-accounts",response_class=HTMLResponse)
def print_accounts(request: Request):
    c=get_connection(); x=c.cursor(); subs=x.execute("SELECT * FROM subscribers ORDER BY name").fetchall(); blocks=[]
    for s in subs:
        inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id",(s['id'],)).fetchall(); total=account_balance(x,s['id'])
        rows="".join(f"<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td></tr>" for i in inv)
        blocks.append(f"<section class='account'><h2>كشف حساب: {esc(s['name'])}</h2><p>الهاتف: {esc(s['phone'])} | العنوان: {esc(s['address'])}</p><p><b>الرصيد المتبقي: {money(total)}</b></p><table><tr><th>الفاتورة</th><th>التاريخ</th><th>المطلوب</th><th>المدفوع</th><th>المتبقي</th></tr>{rows}</table></section>")
    c.close(); controls="<div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة الجميع</button><a class='btn' href='/pdf-accounts'>📄 PDF للجميع</a><button class='btn' onclick='sharePdf(&quot;/pdf-accounts&quot;,&quot;كشوف-المشتركين.pdf&quot;)'>📤 مشاركة PDF</button><a class='btn' href='/accounts'>عودة</a></div>"; return f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><style>body{{font-family:Arial;direction:rtl;margin:20px}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:7px;text-align:center}}th{{background:#e8eef5}}.account{{page-break-after:always}}@media print{{.actions{{display:none}}}}</style></head><body>{controls}{''.join(blocks)}</body></html>"

@app.get("/pdf-accounts")
def pdf_accounts(request: Request):
    if WeasyHTML is None:return RedirectResponse('/print-accounts',303)
    c=get_connection(); x=c.cursor(); subs=x.execute("SELECT * FROM subscribers ORDER BY name").fetchall(); blocks=[]
    for s in subs:
        inv=x.execute("SELECT * FROM invoices WHERE subscriber_id=? ORDER BY id",(s['id'],)).fetchall(); total=account_balance(x,s['id'])
        rows="".join(f"<tr><td>{i['id']}</td><td>{i['invoice_date']}</td><td>{money(i['total_due'])}</td><td>{money(invoice_paid(x,i['id']))}</td><td>{money(invoice_balance(x,i['id']))}</td></tr>" for i in inv)
        blocks.append(f"<section class='account'><h2>كشف حساب: {esc(s['name'])}</h2><p>الهاتف: {esc(s['phone'])} | العنوان: {esc(s['address'])}</p><p><b>الرصيد المتبقي: {money(total)}</b></p><table><tr><th>الفاتورة</th><th>التاريخ</th><th>المطلوب</th><th>المدفوع</th><th>المتبقي</th></tr>{rows}</table></section>")
    c.close(); html=f"<html lang='ar' dir='rtl'><head><meta charset='UTF-8'><style>body{{font-family:Arial;direction:rtl;margin:20px}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:7px;text-align:center}}th{{background:#e8eef5}}.account{{page-break-after:always}}</style></head><body>{''.join(blocks)}</body></html>"; pdf=WeasyHTML(string=html,base_url=str(BASE_DIR)).write_pdf(); return Response(pdf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="accounts.pdf"'})


# =========================================================
# تقرير المتأخرات الشامل
# =========================================================

@app.get("/report-arrears", response_class=HTMLResponse)
def report_arrears(request: Request):
    c=get_connection(); x=c.cursor(); subs=x.execute("SELECT id,name,phone,address FROM subscribers ORDER BY name").fetchall(); data=[]; total=0
    for s in subs:
        bal=account_balance(x,s['id'])
        if bal > 0:
            data.append((s,bal)); total += bal
    c.close()
    rows="".join(f"<tr><td>{s['id']}</td><td>{esc(s['name'])}</td><td>{esc(s['phone'])}</td><td>{esc(s['address'])}</td><td class='money-cell'>{money(bal)}</td><td class='screen-only'><a class='btn' href='/account/{s['id']}'>الحساب</a> <a class='btn purple' href='/whatsapp/arrears/{s['id']}'>واتساب</a></td></tr>" for s,bal in data)
    if not rows:
        rows="<tr><td colspan='6'>لا توجد متأخرات حاليًا.</td></tr>"
    return f"""<!doctype html><html lang='ar' dir='rtl'><head>
<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>
<title>تقرير المتأخرات - نظام مشروع الغميس</title>
<style>
*{{box-sizing:border-box}}
body{{font-family:Arial,Tahoma,sans-serif;direction:rtl;background:#fff;color:#222;margin:0;padding:12mm}}
.report{{width:100%;max-width:198mm;margin:0 auto}}
.header{{text-align:center;border-bottom:2px solid #222;padding-bottom:7px;margin-bottom:12px}}
.header h1{{font-size:19px;margin:0 0 5px;font-weight:700}}
.header .sub{{font-size:12px;color:#555}}
.summary{{display:flex;gap:10px;margin-bottom:12px}}
.box{{flex:1;border:1px solid #bbb;border-radius:7px;padding:9px;text-align:center}}
.box b{{display:block;font-size:17px;margin-bottom:3px}}
.box span{{font-size:11px}}
table{{width:100%;border-collapse:collapse;table-layout:fixed}}
th,td{{border:1px solid #555;padding:7px 5px;text-align:center;font-size:11px;vertical-align:middle;word-wrap:break-word}}
th{{background:#e8eef5;font-weight:bold}}
.money-cell{{font-weight:bold;color:#c00;white-space:nowrap}}
.actions{{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:14px 0}}
.actions button,.actions a{{font-family:inherit;font-size:13px;padding:8px 14px;border-radius:6px;border:1px solid #aaa;text-decoration:none;cursor:pointer}}
.footer{{text-align:center;margin-top:18px;padding-top:8px;border-top:1px solid #aaa;font-size:10px;color:#555}}
@media(max-width:700px){{body{{padding:8px}}.summary{{flex-direction:column}}.report{{max-width:none}}table{{display:block;overflow-x:auto;white-space:nowrap}}th,td{{font-size:10px;padding:6px}}}}
@media print{{body{{padding:4mm;background:#fff}}.screen-only,.actions{{display:none!important}}.report{{max-width:none;width:100%}}.header h1{{font-size:17px}}th,td{{font-size:10px;padding:6px}}@page{{size:A4 portrait;margin:5mm}}}}
</style></head><body><div class='report'>
<div class='header'><h1>تقرير المتأخرات للمشتركين</h1><div class='sub'>نظام مشروع الغميس - المياه والكهرباء</div></div>
<div class='summary'><div class='box'><b>{len(data)}</b><span>عدد المتأخرين</span></div><div class='box'><b>{money(total)}</b><span>إجمالي المتأخرات الحالية</span></div></div>
<div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة التقرير</button><a href='/pdf-report-arrears'>📄 PDF حفظ</a><button type='button' onclick='sharePdf("/pdf-report-arrears","تقرير-المتأخرات.pdf")'>📤 مشاركة PDF</button><a href='/reports'>عودة</a></div>
<table><tr><th>رقم المشترك</th><th>الاسم</th><th>الهاتف</th><th>العنوان</th><th>المتبقي</th><th class='screen-only'>الإجراء</th></tr>{rows}</table>
<div class='footer'><b>برمجة وتصميم : ابو سعــــــــــــيد</b><br>737698405 / 780722005</div>
</div><script>
async function sharePdf(url,filename){{try{{const r=await fetch(url);if(!r.ok)throw new Error();const blob=await r.blob();const file=new File([blob],filename,{{type:'application/pdf'}});if(navigator.share&&(!navigator.canShare||navigator.canShare({{files:[file]}}))){{await navigator.share({{title:filename,text:'مستند PDF - نظام مشروع الغميس',files:[file]}})}}else{{window.open(url,'_blank')}}}}catch(e){{window.open(url,'_blank')}}}}
</script></body></html>"""


@app.get("/pdf-report-arrears")
def pdf_report_arrears(request: Request):
    if WeasyHTML is None:
        return RedirectResponse('/report-arrears',303)
    c=get_connection(); x=c.cursor(); subs=x.execute("SELECT id,name,phone,address FROM subscribers ORDER BY name").fetchall(); data=[]; total=0
    for sub in subs:
        bal=account_balance(x,sub['id'])
        if bal > 0:
            data.append([sub['id'],esc(sub['name']),esc(sub['phone']),esc(sub['address']),money(bal),''])
            total += bal
    c.close()
    pdf=generic_report_pdf('تقرير المتأخرات للمشتركين',['رقم المشترك','الاسم','الهاتف','العنوان','المتبقي',''],data,f'<p><b>عدد المتأخرين: {len(data)} — إجمالي المتأخرات: {money(total)}</b></p>')
    return Response(pdf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="report-arrears.pdf"'})


# =========================================================
# واتساب
# =========================================================

@app.get("/whatsapp", response_class=HTMLResponse)
def whatsapp_page(request: Request):
    c=get_connection(); x=c.cursor()
    overdue=[]
    subs=x.execute("SELECT id,name,phone FROM subscribers ORDER BY name").fetchall()
    for s in subs:
        bal=account_balance(x,s['id'])
        if bal>0 and normalize_phone(s['phone']): overdue.append((s,bal))
    invoices=x.execute("""
        SELECT i.id,i.total_due,i.invoice_date,s.name,s.phone
        FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id
        ORDER BY i.id DESC
    """).fetchall()
    c.close()
    overdue_rows="".join(f"<tr><td>{s['id']}</td><td>{esc(s['name'])}</td><td>{esc(s['phone'])}</td><td class='red'>{money(bal)}</td><td><a class='btn purple' href='/whatsapp/arrears/{s['id']}'>رسالة المتأخرات</a></td></tr>" for s,bal in overdue)
    invoice_rows="".join(f"<tr><td>{i['id']}</td><td>{esc(i['name'])}</td><td>{money(i['total_due'])}</td><td>{esc(i['phone'])}</td><td><a class='btn purple' href='/whatsapp/invoice/{i['id']}'>إرسال الفاتورة</a></td></tr>" for i in invoices)
    body=f"""
    <div class="card"><h2>📱 واتساب</h2><p>الرسائل تفتح محادثة واتساب جاهزة بالنص. وللإرسال الجماعي تظهر قائمة متتابعة حتى تختار المشتركين وتراجع الرسالة قبل الإرسال.</p></div>
    <div class="card"><h3>تنبيهات المتأخرات</h3><div class="table-wrap"><table><tr><th>المشترك</th><th>الاسم</th><th>الهاتف</th><th>المتبقي</th><th>الإجراء</th></tr>{overdue_rows or '<tr><td colspan="5">لا يوجد مشترك عليه متأخرات وله رقم هاتف مسجل.</td></tr>'}</table></div></div>
    <div class="card"><h3>الفواتير</h3><div class="actions"><a class="btn green" href="/whatsapp/invoices">قائمة الإرسال الجماعي</a></div><br><div class="table-wrap"><table><tr><th>الفاتورة</th><th>المشترك</th><th>المطلوب</th><th>الهاتف</th><th>الإجراء</th></tr>{invoice_rows}</table></div></div>
    """
    return page(request,"واتساب",body)


@app.get("/whatsapp/arrears/{subscriber_id}", response_class=HTMLResponse)
def whatsapp_arrears(request: Request,subscriber_id:int):
    c=get_connection(); x=c.cursor(); s=x.execute("SELECT * FROM subscribers WHERE id=?",(subscriber_id,)).fetchone()
    if not s:c.close(); return HTMLResponse("<h2>المشترك غير موجود</h2>")
    balance=account_balance(x,subscriber_id); c.close()
    message=f"السلام عليكم {s['name']}\nنود تنبيهكم بأن المتبقي على حسابكم في مشروع الغميس هو: {money(balance)}\nشاكرين تعاونكم."
    url=whatsapp_url(s['phone'],message)
    c=get_connection(); c.execute("INSERT INTO whatsapp_logs(subscriber_id,sent_at,kind,phone,message,status) VALUES(?,?,?,?,?,?)",(subscriber_id,datetime.now().isoformat(timespec='seconds'),'arrears',s['phone'],message,'مجهز للإرسال')); c.commit(); c.close()
    body=f"""<div class="card" style="max-width:800px;margin:auto"><h2>📱 تنبيه متأخرات: {esc(s['name'])}</h2><p>المتبقي الحالي: <b class="red">{money(balance)}</b></p><textarea rows="6">{esc(message)}</textarea><br><br>{'<a class="btn green" target="_blank" href="'+url+'">فتح واتساب وإرسال الرسالة</a>' if url else '<div class="flash error">لا يوجد رقم هاتف صالح لهذا المشترك.</div>'}<a class="btn gray" href="/whatsapp">عودة</a></div>"""
    return page(request,"تنبيه متأخرات واتساب",body)


@app.get("/whatsapp/invoice/{invoice_id}", response_class=HTMLResponse)
def whatsapp_invoice(request: Request,invoice_id:int):
    c=get_connection(); x=c.cursor(); i=x.execute("SELECT i.*,s.name,s.phone FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id WHERE i.id=?",(invoice_id,)).fetchone()
    if not i:c.close(); return HTMLResponse("<h2>الفاتورة غير موجودة</h2>")
    pdf_url=public_invoice_url(request,invoice_id,True)
    view_url=public_invoice_url(request,invoice_id,False)
    message=f"السلام عليكم {i['name']}\nفاتورتكم من مشروع الغميس رقم {i['id']} بقيمة {money(i['total_due'])}.\nرابط الفاتورة: {view_url}\nرابط PDF: {pdf_url}"
    c.execute("INSERT INTO whatsapp_logs(invoice_id,subscriber_id,sent_at,kind,phone,message,status) VALUES(?,?,?,?,?,?,?)",(invoice_id,i['subscriber_id'],datetime.now().isoformat(timespec='seconds'),'invoice',i['phone'],message,'مجهز للإرسال')); c.commit(); c.close()
    url=whatsapp_url(i['phone'],message)
    body=f"""<div class="card" style="max-width:850px;margin:auto"><h2>📱 إرسال الفاتورة رقم {invoice_id} عبر واتساب</h2><p>المشترك: <b>{esc(i['name'])}</b> — المبلغ المطلوب: <b>{money(i['total_due'])}</b></p><textarea rows="8">{esc(message)}</textarea><br><br>{'<a class="btn green" target="_blank" href="'+url+'">فتح واتساب وإرسال</a>' if url else '<div class="flash error">لا يوجد رقم هاتف صالح لهذا المشترك.</div>'}<a class="btn gray" href="/invoice/{invoice_id}">الفاتورة</a></div>"""
    return page(request,"إرسال فاتورة عبر واتساب",body)


@app.get("/whatsapp/invoices", response_class=HTMLResponse)
def whatsapp_invoices(request: Request):
    c=get_connection(); x=c.cursor(); inv=x.execute("SELECT i.id,i.total_due,s.name,s.phone FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id ORDER BY i.id DESC").fetchall(); c.close()
    rows=[]
    for i in inv:
        if not normalize_phone(i['phone']):
            continue
        pdf_url=public_invoice_url(request,i['id'],True); view_url=public_invoice_url(request,i['id'],False)
        msg=f"السلام عليكم {i['name']}\nفاتورتكم رقم {i['id']} من مشروع الغميس بقيمة {money(i['total_due'])}.\nالفاتورة: {view_url}\nPDF: {pdf_url}"
        url=whatsapp_url(i['phone'],msg)
        rows.append(f"<tr><td>{i['id']}</td><td>{esc(i['name'])}</td><td>{esc(i['phone'])}</td><td>{money(i['total_due'])}</td><td><a class='btn purple' target='_blank' href='{url}'>إرسال واتساب</a></td></tr>")
    body=f"""<div class="card"><h2>📱 إرسال الفواتير بشكل جماعي</h2><p>هذه الشاشة تجمع الفواتير في قائمة واحدة؛ يمكنك الإرسال للمشتركين واحدًا بعد الآخر مع مراجعة الرسالة.</p><div class="table-wrap"><table><tr><th>الفاتورة</th><th>المشترك</th><th>الهاتف</th><th>المطلوب</th><th>الإجراء</th></tr>{''.join(rows) or '<tr><td colspan="5">لا توجد فواتير بمشتركين لديهم أرقام صالحة.</td></tr>'}</table></div></div>"""
    return page(request,"إرسال الفواتير عبر واتساب",body)


# =========================================================
# روابط الفاتورة العامة (للمشاركة عبر واتساب)
# =========================================================

def check_public_token(invoice_id, token):
    return hmac.compare_digest(public_token(invoice_id), token or "")


@app.get("/shared/invoice/{invoice_id}", response_class=HTMLResponse)
def shared_invoice(invoice_id:int,token:str=""):
    if not check_public_token(invoice_id,token):
        return HTMLResponse("<h2>الرابط غير صالح.</h2>",status_code=403)
    c=get_connection(); x=c.cursor(); content=invoice_card(x,invoice_id); c.close()
    return f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>فاتورة رقم {invoice_id}</title>{INVOICE_CSS}</head><body>{content}</body></html>"


@app.get("/shared/invoice/{invoice_id}/pdf")
def shared_invoice_pdf(invoice_id:int,token:str=""):
    if not check_public_token(invoice_id,token):
        return HTMLResponse("الرابط غير صالح.",status_code=403)
    if WeasyHTML is None:
        return RedirectResponse(f"/shared/invoice/{invoice_id}?token={quote(token)}",303)
    c=get_connection(); x=c.cursor(); content=invoice_card(x,invoice_id); c.close()
    pdf=WeasyHTML(string=f"<html lang='ar' dir='rtl'><head><meta charset='UTF-8'>{INVOICE_CSS}</head><body>{content}</body></html>",base_url=str(BASE_DIR)).write_pdf()
    return Response(pdf,media_type="application/pdf",headers={"Content-Disposition":f'inline; filename="invoice_{invoice_id}.pdf"'})


# =========================================================
# المصروفات
# =========================================================

@app.get("/expenses", response_class=HTMLResponse)
def expenses_page(request: Request):
    c=get_connection(); rows=c.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall(); c.close(); total=sum(float(r['amount'] or 0) for r in rows)
    table="".join(f"<tr><td>{r['id']}</td><td>{r['expense_date']}</td><td>{esc(r['item'])}</td><td>{money(r['amount'])}</td><td>{esc(r['notes'])}</td><td><a class='btn orange' href='/edit-expense/{r['id']}'>تعديل</a><a class='btn red' href='/delete-expense/{r['id']}' onclick=\"return confirm('حذف المصروف؟')\">حذف</a></td></tr>" for r in rows)
    body=f"""<div class="card"><h2>💸 المصروفات</h2><form method="post" action="/save-expense"><div class="grid"><input name="expense_date" type="date" value="{date.today().isoformat()}" required><input name="item" placeholder="بيان المصروف" required><input name="amount" type="number" step=".01" required><input name="notes" placeholder="ملاحظات"></div><br><button>حفظ المصروف</button></form></div><div class="card"><p><b>الإجمالي: {money(total)}</b></p><div class='table-wrap'><table><tr><th>رقم</th><th>التاريخ</th><th>البيان</th><th>المبلغ</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div></div>"""
    return page(request,"المصروفات",body)


@app.post("/save-expense")
def save_expense(request: Request,expense_date:str=Form(...),item:str=Form(...),amount:float=Form(...),notes:str=Form("")):
    c=get_connection(); c.execute("INSERT INTO expenses(expense_date,item,amount,notes) VALUES(?,?,?,?)",(expense_date,item,amount,notes)); c.commit(); c.close(); set_flash(request,"تم حفظ المصروف."); return RedirectResponse("/expenses",303)


@app.get("/edit-expense/{expense_id}",response_class=HTMLResponse)
def edit_expense(request: Request,expense_id:int):
    c=get_connection(); r=c.execute("SELECT * FROM expenses WHERE id=?",(expense_id,)).fetchone(); c.close();
    if not r:return HTMLResponse("<h2>المصروف غير موجود</h2>")
    return page(request,"تعديل المصروف",f"""<div class='card'><h2>تعديل المصروف</h2><form method='post' action='/update-expense/{r['id']}'><div class='grid'><input name='expense_date' type='date' value='{r['expense_date']}' required><input name='item' value='{esc(r['item'])}' required><input name='amount' type='number' step='.01' value='{r['amount']}' required><input name='notes' value='{esc(r['notes'])}'></div><br><button>حفظ</button></form></div>""")


@app.post("/update-expense/{expense_id}")
def update_expense(request: Request,expense_id:int,expense_date:str=Form(...),item:str=Form(...),amount:float=Form(...),notes:str=Form("")):
    c=get_connection(); c.execute("UPDATE expenses SET expense_date=?,item=?,amount=?,notes=? WHERE id=?",(expense_date,item,amount,notes,expense_id)); c.commit(); c.close(); set_flash(request,"تم تعديل المصروف."); return RedirectResponse("/expenses",303)


@app.get("/delete-expense/{expense_id}")
def delete_expense(request: Request,expense_id:int):
    c=get_connection(); c.execute("DELETE FROM expenses WHERE id=?",(expense_id,)); c.commit(); c.close(); set_flash(request,"تم حذف المصروف.","warning"); return RedirectResponse("/expenses",303)


# =========================================================
# الموظفين
# =========================================================

@app.get("/employees", response_class=HTMLResponse)
def employees_page(request: Request):
    c=get_connection(); rows=c.execute("SELECT * FROM employees ORDER BY id DESC").fetchall(); c.close()
    table="".join(f"<tr><td>{r['id']}</td><td>{esc(r['name'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['job'])}</td><td>{money(r['salary'])}</td><td>{esc(r['notes'])}</td><td><a class='btn orange' href='/edit-employee/{r['id']}'>تعديل</a><a class='btn red' href='/delete-employee/{r['id']}' onclick=\"return confirm('حذف الموظف؟')\">حذف</a></td></tr>" for r in rows)
    body=f"""<div class='card'><h2>👨‍💼 الموظفين</h2><form method='post' action='/save-employee'><div class='grid'><input name='name' placeholder='اسم الموظف' required><input name='phone' placeholder='الهاتف'><input name='job' placeholder='الوظيفة'><input name='salary' type='number' step='.01' placeholder='الراتب'><input name='notes' placeholder='ملاحظات'></div><br><button>حفظ الموظف</button></form></div><div class='card table-wrap'><table><tr><th>رقم</th><th>الاسم</th><th>الهاتف</th><th>الوظيفة</th><th>الراتب</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div>"""
    return page(request,'الموظفين',body)


@app.post('/save-employee')
def save_employee(request: Request,name:str=Form(...),phone:str=Form(''),job:str=Form(''),salary:float=Form(0),notes:str=Form('')):
    c=get_connection(); c.execute('INSERT INTO employees(name,phone,job,salary,notes) VALUES(?,?,?,?,?)',(name,phone,job,salary,notes)); c.commit(); c.close(); set_flash(request,'تم حفظ الموظف.'); return RedirectResponse('/employees',303)


@app.get('/edit-employee/{employee_id}',response_class=HTMLResponse)
def edit_employee(request: Request,employee_id:int):
    c=get_connection(); r=c.execute('SELECT * FROM employees WHERE id=?',(employee_id,)).fetchone(); c.close();
    if not r:return HTMLResponse('<h2>الموظف غير موجود</h2>')
    return page(request,'تعديل الموظف',f"""<div class='card'><h2>تعديل الموظف</h2><form method='post' action='/update-employee/{r['id']}'><div class='grid'><input name='name' value='{esc(r['name'])}' required><input name='phone' value='{esc(r['phone'])}'><input name='job' value='{esc(r['job'])}'><input name='salary' type='number' step='.01' value='{r['salary']}'><input name='notes' value='{esc(r['notes'])}'></div><br><button>حفظ</button></form></div>""")


@app.post('/update-employee/{employee_id}')
def update_employee(request: Request,employee_id:int,name:str=Form(...),phone:str=Form(''),job:str=Form(''),salary:float=Form(0),notes:str=Form('')):
    c=get_connection(); c.execute('UPDATE employees SET name=?,phone=?,job=?,salary=?,notes=? WHERE id=?',(name,phone,job,salary,notes,employee_id)); c.commit(); c.close(); set_flash(request,'تم تعديل الموظف.'); return RedirectResponse('/employees',303)


@app.get('/delete-employee/{employee_id}')
def delete_employee(request: Request,employee_id:int):
    c=get_connection(); c.execute('DELETE FROM salaries WHERE employee_id=?',(employee_id,)); c.execute('DELETE FROM employees WHERE id=?',(employee_id,)); c.commit(); c.close(); set_flash(request,'تم حذف الموظف.','warning'); return RedirectResponse('/employees',303)


# =========================================================
# الرواتب
# =========================================================

@app.get('/salaries',response_class=HTMLResponse)
def salaries_page(request: Request):
    c=get_connection(); x=c.cursor()
    rows=x.execute("SELECT sa.*,e.name FROM salaries sa JOIN employees e ON sa.employee_id=e.id ORDER BY sa.id DESC").fetchall()
    emps=x.execute("SELECT id,name,salary FROM employees ORDER BY name").fetchall(); c.close()
    opts=''.join(f'<option value="{e["id"]}" data-salary="{float(e["salary"] or 0)}">{esc(e["name"])}</option>' for e in emps)
    table=''.join(
        f"<tr><td>{r['id']}</td><td>{r['salary_date']}</td><td>{esc(r['name'])}</td>"
        f"<td>{money(r['base_salary'])}</td><td>{money(r['additions'])}</td><td>{money(r['deductions'])}</td>"
        f"<td><b>{money(r['net_amount'] or r['amount'])}</b></td>"
        f"<td>{'✅ مصروف' if r['paid'] else '⏳ غير مصروف'}</td><td>{r['payment_date'] or '-'}</td>"
        f"<td>{esc(r['notes'])}</td><td><a class='btn orange' href='/edit-salary/{r['id']}'>تعديل</a> "
        f"<a class='btn red' href='/delete-salary/{r['id']}' onclick=\"return confirm('حذف سجل الراتب؟')\">حذف</a> "
        + (f"<a class='btn green' href='/pay-salary/{r['id']}' onclick=\"return confirm('تأكيد صرف هذا الراتب وإضافته إلى المصروفات؟')\">💰 صرف الراتب</a>" if not r['paid'] else '')
        + '</td></tr>' for r in rows)
    body=f"""
    <div class='card'>
      <h2>💵 الرواتب الشهرية</h2>
      <p class='muted'>سجّل الراتب الأساسي، ثم أضف البدلات/الإضافات والخصومات. لا يدخل الراتب في المصروفات إلا عند الضغط على «صرف الراتب».</p>
      <form method='post' action='/save-salary'>
        <div class='grid'>
          <select name='employee_id' id='salaryEmployee' required><option value=''>اختر الموظف</option>{opts}</select>
          <input name='salary_date' type='date' value='{date.today().isoformat()}' required>
          <input name='base_salary' id='baseSalary' type='number' step='.01' min='0' placeholder='الراتب الأساسي' required>
          <input name='additions' id='additions' type='number' step='.01' min='0' value='0' placeholder='الإضافات / البدلات'>
          <input name='deductions' id='deductions' type='number' step='.01' min='0' value='0' placeholder='الخصومات'>
          <input id='netSalary' type='number' step='.01' value='0' placeholder='صافي الراتب' readonly>
          <input name='notes' placeholder='ملاحظات'>
        </div>
        <p><b>صافي الراتب: <span id='netText'>0</span> ر.ي</b></p>
        <button>➕ حفظ راتب الشهر</button>
      </form>
    </div>
    <div class='card table-wrap'>
      <table><tr><th>رقم</th><th>التاريخ/الشهر</th><th>الموظف</th><th>الأساسي</th><th>الإضافات</th><th>الخصومات</th><th>الصافي</th><th>الحالة</th><th>تاريخ الصرف</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table>
    </div>
    <script>
    const emp=document.getElementById('salaryEmployee'), base=document.getElementById('baseSalary'), add=document.getElementById('additions'), ded=document.getElementById('deductions'), net=document.getElementById('netSalary'), nt=document.getElementById('netText');
    function calcSalary(){{ const b=parseFloat(base.value)||0, a=parseFloat(add.value)||0, d=parseFloat(ded.value)||0; const n=Math.max(0,b+a-d); net.value=n.toFixed(2); nt.textContent=n.toLocaleString('en-US',{{minimumFractionDigits:2,maximumFractionDigits:2}}); }}
    emp.addEventListener('change',()=>{{const o=emp.options[emp.selectedIndex]; if(o && o.dataset.salary) base.value=o.dataset.salary; calcSalary();}});
    [base,add,ded].forEach(e=>e.addEventListener('input',calcSalary)); calcSalary();
    </script>
    """
    return page(request,'الرواتب',body)


@app.post('/save-salary')
def save_salary(request: Request,employee_id:int=Form(...),salary_date:str=Form(...),base_salary:float=Form(...),additions:float=Form(0),deductions:float=Form(0),notes:str=Form('')):
    base=max(0,float(base_salary or 0)); additions=max(0,float(additions or 0)); deductions=max(0,float(deductions or 0)); net=max(0,base+additions-deductions)
    c=get_connection(); c.execute('INSERT INTO salaries(employee_id,salary_date,amount,notes,base_salary,additions,deductions,net_amount,paid,payment_date) VALUES(?,?,?,?,?,?,?,?,0,NULL)',(employee_id,salary_date,net,notes,base,additions,deductions,net)); c.commit(); c.close(); set_flash(request,'تم حفظ راتب الشهر. لم يُصرف بعد.'); return RedirectResponse('/salaries',303)


@app.get('/edit-salary/{salary_id}',response_class=HTMLResponse)
def edit_salary(request: Request,salary_id:int):
    c=get_connection(); r=c.execute('SELECT * FROM salaries WHERE id=?',(salary_id,)).fetchone(); emps=c.execute('SELECT id,name FROM employees ORDER BY name').fetchall(); c.close()
    if not r:return HTMLResponse('<h2>الراتب غير موجود</h2>')
    opts=''.join(f'<option value="{e["id"]}" {"selected" if e["id"]==r["employee_id"] else ""}>{esc(e["name"])}</option>' for e in emps)
    if r['paid']:
        return page(request,'تعديل الراتب',f"<div class='card'><h2>راتب مصروف</h2><p>هذا الراتب تم صرفه بتاريخ <b>{r['payment_date']}</b> ولا يمكن تعديل مبالغ الصرف.</p></div>")
    return page(request,'تعديل الراتب',f"""<div class='card'><h2>تعديل راتب الشهر</h2><form method='post' action='/update-salary/{r['id']}'><div class='grid'><select name='employee_id'>{opts}</select><input name='salary_date' type='date' value='{r['salary_date']}' required><input name='base_salary' type='number' step='.01' value='{r['base_salary']}' required><input name='additions' type='number' step='.01' value='{r['additions']}' required><input name='deductions' type='number' step='.01' value='{r['deductions']}' required><input name='notes' value='{esc(r['notes'])}'></div><br><button>حفظ التعديل</button></form></div>""")


@app.post('/update-salary/{salary_id}')
def update_salary(request: Request,salary_id:int,employee_id:int=Form(...),salary_date:str=Form(...),base_salary:float=Form(...),additions:float=Form(0),deductions:float=Form(0),notes:str=Form('')):
    c=get_connection(); r=c.execute('SELECT paid FROM salaries WHERE id=?',(salary_id,)).fetchone()
    if not r: c.close(); return HTMLResponse('<h2>الراتب غير موجود</h2>')
    if r['paid']: c.close(); set_flash(request,'لا يمكن تعديل راتب تم صرفه.','warning'); return RedirectResponse('/salaries',303)
    base=max(0,float(base_salary or 0)); additions=max(0,float(additions or 0)); deductions=max(0,float(deductions or 0)); net=max(0,base+additions-deductions)
    c.execute('UPDATE salaries SET employee_id=?,salary_date=?,amount=?,notes=?,base_salary=?,additions=?,deductions=?,net_amount=? WHERE id=?',(employee_id,salary_date,net,notes,base,additions,deductions,net,salary_id)); c.commit(); c.close(); set_flash(request,'تم تعديل راتب الشهر.'); return RedirectResponse('/salaries',303)


@app.get('/pay-salary/{salary_id}')
def pay_salary(request: Request,salary_id:int):
    c=get_connection(); r=c.execute('SELECT sa.*,e.name FROM salaries sa JOIN employees e ON sa.employee_id=e.id WHERE sa.id=?',(salary_id,)).fetchone()
    if not r: c.close(); set_flash(request,'الراتب غير موجود.','warning'); return RedirectResponse('/salaries',303)
    if r['paid']: c.close(); set_flash(request,'هذا الراتب مصروف مسبقًا ولا يمكن صرفه مرة أخرى.','warning'); return RedirectResponse('/salaries',303)
    amount=float(r['net_amount'] or r['amount'] or 0); pay_date=date.today().isoformat()
    c.execute('UPDATE salaries SET paid=1,payment_date=? WHERE id=?',(pay_date,salary_id))
    c.execute('INSERT INTO expenses(expense_date,item,amount,notes) VALUES(?,?,?,?)',(pay_date,f"راتب الموظف: {r['name']} - {r['salary_date']}",amount,'صرف راتب شهري'))
    c.commit(); c.close(); set_flash(request,f'تم صرف راتب {r["name"]} وإضافته إلى المصروفات.'); return RedirectResponse('/salaries',303)


@app.get('/delete-salary/{salary_id}')
def delete_salary(request: Request,salary_id:int):
    c=get_connection(); r=c.execute('SELECT paid FROM salaries WHERE id=?',(salary_id,)).fetchone()
    if r and r['paid']:
        c.close(); set_flash(request,'لا يمكن حذف راتب تم صرفه لأنه مرتبط بسجل المصروفات.','warning'); return RedirectResponse('/salaries',303)
    c.execute('DELETE FROM salaries WHERE id=?',(salary_id,)); c.commit(); c.close(); set_flash(request,'تم حذف سجل الراتب.','warning'); return RedirectResponse('/salaries',303)


# =========================================================
# التبرعات
# =========================================================

@app.get('/donations',response_class=HTMLResponse)
def donations_page(request: Request):
    c=get_connection(); rows=c.execute('SELECT * FROM donations ORDER BY id DESC').fetchall(); c.close(); total=sum(float(r['amount'] or 0) for r in rows)
    table=''.join(f"<tr><td>{r['id']}</td><td>{r['donation_date']}</td><td>{esc(r['donor'])}</td><td>{money(r['amount'])}</td><td>{esc(r['purpose'])}</td><td>{esc(r['notes'])}</td><td><a class='btn orange' href='/edit-donation/{r['id']}'>تعديل</a><a class='btn red' href='/delete-donation/{r['id']}' onclick=\"return confirm('حذف التبرع؟')\">حذف</a></td></tr>" for r in rows)
    body=f"""<div class='card'><h2>🎁 التبرعات</h2><form method='post' action='/save-donation'><div class='grid'><input name='donation_date' type='date' value='{date.today().isoformat()}' required><input name='donor' placeholder='اسم المتبرع'><input name='amount' type='number' step='.01' required><input name='purpose' placeholder='الغرض'><input name='notes' placeholder='ملاحظات'></div><br><button>حفظ التبرع</button></form></div><div class='card'><p><b>الإجمالي: {money(total)}</b></p><div class='table-wrap'><table><tr><th>رقم</th><th>التاريخ</th><th>المتبرع</th><th>المبلغ</th><th>الغرض</th><th>ملاحظات</th><th>الإجراء</th></tr>{table}</table></div></div>"""
    return page(request,'التبرعات',body)


@app.post('/save-donation')
def save_donation(request: Request,donation_date:str=Form(...),donor:str=Form(''),amount:float=Form(...),purpose:str=Form(''),notes:str=Form('')):
    c=get_connection(); c.execute('INSERT INTO donations(donation_date,donor,amount,purpose,notes) VALUES(?,?,?,?,?)',(donation_date,donor,amount,purpose,notes)); c.commit(); c.close(); set_flash(request,'تم حفظ التبرع.'); return RedirectResponse('/donations',303)


@app.get('/edit-donation/{donation_id}',response_class=HTMLResponse)
def edit_donation(request: Request,donation_id:int):
    c=get_connection(); r=c.execute('SELECT * FROM donations WHERE id=?',(donation_id,)).fetchone(); c.close();
    if not r:return HTMLResponse('<h2>التبرع غير موجود</h2>')
    return page(request,'تعديل التبرع',f"""<div class='card'><h2>تعديل التبرع</h2><form method='post' action='/update-donation/{r['id']}'><div class='grid'><input name='donation_date' type='date' value='{r['donation_date']}' required><input name='donor' value='{esc(r['donor'])}'><input name='amount' type='number' step='.01' value='{r['amount']}' required><input name='purpose' value='{esc(r['purpose'])}'><input name='notes' value='{esc(r['notes'])}'></div><br><button>حفظ</button></form></div>""")


@app.post('/update-donation/{donation_id}')
def update_donation(request: Request,donation_id:int,donation_date:str=Form(...),donor:str=Form(''),amount:float=Form(...),purpose:str=Form(''),notes:str=Form('')):
    c=get_connection(); c.execute('UPDATE donations SET donation_date=?,donor=?,amount=?,purpose=?,notes=? WHERE id=?',(donation_date,donor,amount,purpose,notes,donation_id)); c.commit(); c.close(); set_flash(request,'تم تعديل التبرع.'); return RedirectResponse('/donations',303)


@app.get('/delete-donation/{donation_id}')
def delete_donation(request: Request,donation_id:int):
    c=get_connection(); c.execute('DELETE FROM donations WHERE id=?',(donation_id,)); c.commit(); c.close(); set_flash(request,'تم حذف التبرع.','warning'); return RedirectResponse('/donations',303)


# =========================================================
# التقارير
# =========================================================

def generic_report(title, headers, rows, summary="", pdf_url=""):
    thead="".join(f"<th>{h}</th>" for h in headers)
    bodyrows="".join("<tr>"+"".join(f"<td>{cell}</td>" for cell in row)+"</tr>" for row in rows)
    pdf_actions = f'<a class="btn gray" href="{pdf_url}">📄 PDF حفظ</a><button class="btn share" type="button" onclick="sharePdf(&quot;{pdf_url}&quot;,&quot;تقرير.pdf&quot;)">📤 مشاركة PDF</button>' if pdf_url else ''
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{esc(title)}</title><style>body{{font-family:Arial;margin:15px;direction:rtl}}h1{{text-align:center}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:6px;text-align:center}}th{{background:#e8eef5}}.actions{{margin:12px 0;display:flex;gap:7px;flex-wrap:wrap}}button,a{{padding:8px 13px}}.btn{{text-decoration:none;background:#607d8b;color:#fff;border-radius:7px}}@media print{{.actions{{display:none}}}}</style></head><body><h1>{esc(title)}</h1>{summary}<div class='actions'><button onclick='window.AndroidPrint?AndroidPrint.printPage():window.print()'>🖨️ طباعة</button>{pdf_actions}<a class='btn' href='/reports'>عودة</a></div><table><tr>{thead}</tr>{bodyrows}</table></body></html>"""


def report_payload(report_name):
    c=get_connection(); x=c.cursor()
    if report_name == 'payments':
        rows=x.execute('SELECT p.id,p.payment_date,s.name,p.invoice_id,p.amount,p.notes FROM payments p JOIN subscribers s ON p.subscriber_id=s.id JOIN invoices i ON p.invoice_id=i.id ORDER BY p.id DESC').fetchall()
        total=sum(float(r['amount'] or 0) for r in rows); c.close()
        return 'تقرير المدفوعات',['رقم','التاريخ','المشترك','الفاتورة','المبلغ','ملاحظات'],[[r['id'],r['payment_date'],esc(r['name']),r['invoice_id'],money(r['amount']),esc(r['notes'])] for r in rows],f'<p><b>الإجمالي: {money(total)}</b></p>'
    if report_name == 'expenses':
        rows=x.execute('SELECT * FROM expenses ORDER BY id DESC').fetchall(); total=sum(float(r['amount'] or 0) for r in rows); c.close()
        return 'تقرير المصروفات',['رقم','التاريخ','البيان','المبلغ','ملاحظات'],[[r['id'],r['expense_date'],esc(r['item']),money(r['amount']),esc(r['notes'])] for r in rows],f'<p><b>الإجمالي: {money(total)}</b></p>'
    if report_name == 'salaries':
        rows=x.execute('SELECT sa.id,sa.salary_date,e.name,sa.amount,sa.notes FROM salaries sa JOIN employees e ON sa.employee_id=e.id ORDER BY sa.id DESC').fetchall(); total=sum(float(r['amount'] or 0) for r in rows); c.close()
        return 'تقرير الرواتب',['رقم','التاريخ','الموظف','المبلغ','ملاحظات'],[[r['id'],r['salary_date'],esc(r['name']),money(r['amount']),esc(r['notes'])] for r in rows],f'<p><b>الإجمالي: {money(total)}</b></p>'
    if report_name == 'donations':
        rows=x.execute('SELECT * FROM donations ORDER BY id DESC').fetchall(); total=sum(float(r['amount'] or 0) for r in rows); c.close()
        return 'تقرير التبرعات',['رقم','التاريخ','المتبرع','المبلغ','الغرض','ملاحظات'],[[r['id'],r['donation_date'],esc(r['donor']),money(r['amount']),esc(r['purpose']),esc(r['notes'])] for r in rows],f'<p><b>الإجمالي: {money(total)}</b></p>'
    if report_name == 'invoices':
        rows=x.execute('SELECT i.id,i.invoice_date,s.name,i.total_due,i.closed FROM invoices i JOIN subscribers s ON i.subscriber_id=s.id ORDER BY i.id DESC').fetchall(); data=[]
        for r in rows:
            paid=invoice_paid(x,r['id']); rem=invoice_balance(x,r['id']); data.append([r['id'],r['invoice_date'],esc(r['name']),money(r['total_due']),money(paid),money(rem),'مغلقة' if r['closed'] else 'مفتوحة'])
        c.close(); return 'تقرير الفواتير',['الفاتورة','التاريخ','المشترك','المطلوب','المدفوع','المتبقي','الحالة'],data,''
    c.close(); raise ValueError('تقرير غير معروف')


def generic_report_pdf(title, headers, rows, summary=''):
    if WeasyHTML is None:
        return None
    thead=''.join(f'<th>{h}</th>' for h in headers)
    bodyrows=''.join('<tr>'+''.join(f'<td>{cell}</td>' for cell in row)+'</tr>' for row in rows)
    html=f"""<html lang='ar' dir='rtl'><head><meta charset='UTF-8'><style>body{{font-family:Arial;direction:rtl;margin:20px}}h1{{text-align:center}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:7px;text-align:center}}th{{background:#e8eef5}}</style></head><body><h1>{esc(title)}</h1>{summary}<table><tr>{thead}</tr>{bodyrows}</table></body></html>"""
    return WeasyHTML(string=html,base_url=str(BASE_DIR)).write_pdf()


@app.get('/pdf-report/{report_name}')
def pdf_report(request: Request, report_name: str):
    try:
        title, headers, rows, summary = report_payload(report_name)
    except ValueError:
        return HTMLResponse('التقرير غير موجود', status_code=404)
    pdf=generic_report_pdf(title,headers,rows,summary)
    if pdf is None:
        return RedirectResponse(f'/report-{report_name}',303)
    return Response(pdf,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="report-{report_name}.pdf"'})


@app.get('/reports',response_class=HTMLResponse)
def reports_page(request: Request):
    c=get_connection(); x=c.cursor()
    payments=float(x.execute('SELECT COALESCE(SUM(amount),0) FROM payments').fetchone()[0] or 0)
    expenses=float(x.execute('SELECT COALESCE(SUM(amount),0) FROM expenses').fetchone()[0] or 0)
    salaries=float(x.execute('SELECT COALESCE(SUM(amount),0) FROM salaries').fetchone()[0] or 0)
    donations=float(x.execute('SELECT COALESCE(SUM(amount),0) FROM donations').fetchone()[0] or 0)
    subscribers=x.execute('SELECT COUNT(*) FROM subscribers').fetchone()[0]
    open_invoices=x.execute('SELECT COUNT(*) FROM invoices WHERE closed=0').fetchone()[0]
    arrears=x.execute("""SELECT COALESCE(SUM(
        MAX(0,COALESCE(s.previous_arrears,0)+COALESCE((SELECT SUM(r.consumption_value) FROM readings r JOIN meters m ON r.meter_id=m.id WHERE m.subscriber_id=s.id),0)-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.subscriber_id=s.id),0))
    ),0) FROM subscribers s""").fetchone()[0]
    c.close()
    body=f"""<div class='card'><h2>📑 التقارير</h2><div class='stats'><div class='stat'><b>{money(payments)}</b><span>المدفوعات</span></div><div class='stat'><b>{money(expenses)}</b><span>المصروفات</span></div><div class='stat'><b>{money(salaries)}</b><span>الرواتب</span></div><div class='stat'><b>{money(donations)}</b><span>التبرعات</span></div><div class='stat'><b>{money(arrears)}</b><span>المتأخرات الحالية</span></div><div class='stat'><b>{subscribers}</b><span>المشتركون</span></div><div class='stat'><b>{open_invoices}</b><span>الفواتير المفتوحة</span></div></div></div>
    <div class='card'><div class='actions'><a class='btn arrears' href='/report-arrears'>تقرير المتأخرات</a><a class='btn' href='/report-payments'>تقرير المدفوعات</a><a class='btn gray' href='/report-expenses'>تقرير المصروفات</a><a class='btn orange' href='/report-salaries'>تقرير الرواتب</a><a class='btn green' href='/report-donations'>تقرير التبرعات</a><a class='btn purple' href='/report-invoices'>تقرير الفواتير</a></div></div>"""
    return page(request,'التقارير',body)


@app.get('/report-payments',response_class=HTMLResponse)
def report_payments(request: Request):
    title, headers, data, summary = report_payload('payments')
    return HTMLResponse(generic_report(title,headers,data,summary,"/pdf-report/payments"))


@app.get('/report-expenses',response_class=HTMLResponse)
def report_expenses(request: Request):
    title, headers, data, summary = report_payload('expenses')
    return HTMLResponse(generic_report(title,headers,data,summary,"/pdf-report/expenses"))


@app.get('/report-salaries',response_class=HTMLResponse)
def report_salaries(request: Request):
    title, headers, data, summary = report_payload('salaries')
    return HTMLResponse(generic_report(title,headers,data,summary,"/pdf-report/salaries"))


@app.get('/report-donations',response_class=HTMLResponse)
def report_donations(request: Request):
    title, headers, data, summary = report_payload('donations')
    return HTMLResponse(generic_report(title,headers,data,summary,"/pdf-report/donations"))


@app.get('/report-invoices',response_class=HTMLResponse)
def report_invoices(request: Request):
    title, headers, data, summary = report_payload('invoices')
    return HTMLResponse(generic_report(title,headers,data,summary,"/pdf-report/invoices"))


# =========================================================
# التشغيل
# =========================================================

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=PORT)

