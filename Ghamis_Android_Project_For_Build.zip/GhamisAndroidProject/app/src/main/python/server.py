import os
import threading
import uvicorn

_started = False
_lock = threading.Lock()

def start_server(data_dir):
    global _started
    with _lock:
        if _started:
            return
        _started = True
    os.environ['GHMAIS_DATA_DIR'] = data_dir
    os.makedirs(os.path.join(data_dir, 'WaterElectricity'), exist_ok=True)
    os.makedirs(os.path.join(data_dir, 'Backup'), exist_ok=True)
    import main
    config = uvicorn.Config(main.app, host='127.0.0.1', port=8765, log_level='warning', access_log=False)
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()
